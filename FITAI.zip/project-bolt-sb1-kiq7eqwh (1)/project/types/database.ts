export interface Profile {
  id: string;
  full_name: string;
  age: number | null;
  weight_kg: number | null;
  height_cm: number | null;
  fitness_level: 'beginner' | 'intermediate' | 'advanced';
  fitness_goal: string;
  avatar_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface Exercise {
  id: string;
  name: string;
  muscle_group: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  equipment: string;
  instructions: string[];
  safety_tips: string[];
  sets_reps: string;
  rest_seconds: number;
  calories_per_set: number;
  icon_name: string;
}

export interface WorkoutPlan {
  id: string;
  name: string;
  description: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  category: string;
  duration_minutes: number;
  calories_estimate: number;
  exercise_ids: string[];
  icon_name: string;
  color: string;
}

export interface WorkoutHistoryItem {
  id: string;
  user_id: string;
  workout_name: string;
  exercises: any[];
  duration_minutes: number;
  calories_burned: number;
  difficulty: string;
  completed_at: string;
  created_at: string;
}

export interface WaterIntake {
  id: string;
  user_id: string;
  glasses: number;
  intake_date: string;
}

export interface ChatMessage {
  id: string;
  user_id: string;
  role: 'user' | 'assistant';
  content: string;
  created_at: string;
}

export interface MealSuggestion {
  id: string;
  name: string;
  type: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  calories: number;
  protein_g: number;
  carbs_g: number;
  fats_g: number;
  ingredients: string[];
  description: string;
}

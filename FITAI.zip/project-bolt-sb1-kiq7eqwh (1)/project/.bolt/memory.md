# Project memory

## Product intent & audience

- FITAI: full-stack AI gym coach mobile app
- Features: workout plans, interactive OpenAI chatbot, diet tracking, progress monitoring
- Target: gym users seeking personalized AI-driven fitness coaching

## Brand personality & voice

- Fitness-tech; energetic but focused
- Implied tone: motivational, data-aware, coach-like

## Visual design & UX direction

- Premium dark theme: black + dark grey backgrounds, neon-green accent
- Mobile-first (Expo); must fill entire Android screen, no horizontal scroll, no cut-off content
- Remove unnecessary blank spaces and extra margins
- Bottom tab navigation fixed and properly visible; content must have bottom padding so tab bar never covers it
- Buttons must be large/easy to tap
- Workout page: day + workout name at top, progress bar, live timer (play/pause/reset), exercise-by-exercise navigation (one card at a time) with Previous/Next buttons, dot indicators, Finish button on last exercise
- Exercise cards: rounded, large demo image (responsive up to ~280px), name overlaid on image, stat badges (sets/reps, rest, calories), numbered "How to Perform" instructions, beginner-friendly "Proper Form Guide" section
- Modern typography; clean professional spacing
- Test at Android mobile screen sizes

## Decisions, constraints & rationale

- Framework: Expo with Expo Router (file-based routing)
- Backend: Supabase (auth sessions + data)
- Route structure: root Stack wraps `(auth)` and `(tabs)` route groups
- `app/index.tsx` is the root entry point — redirects to login on startup
- AuthGate component manages session-based redirects (login → home dashboard)
- Root Stack must explicitly register `(auth)` and `(tabs)` groups or navigation breaks
- OpenAI integration for chatbot feature
- Shared UI components live in `components/ui.tsx` (e.g. NeonButton)
- Preserving existing features, workout data, exercise names, and functionality is a hard constraint during redesigns/fixes
- Workout page redesigned to exercise-by-exercise flow instead of long scroll; weekly plan, exercise data, and workout history saving preserved

## Open questions & assumptions

- Specific tab screen names beyond home dashboard and workout day still not fully documented
- Supabase schema and table structure not yet documented
- OpenAI chatbot implementation details (model, prompt strategy) not yet documented
- Whether diet tracking and progress monitoring have dedicated tabs or sub-screens unclear
- Exercise demonstration images are currently placeholders; real human image/video sourcing not confirmed
- No `.bolt/prompt` present; no global instructions to reference
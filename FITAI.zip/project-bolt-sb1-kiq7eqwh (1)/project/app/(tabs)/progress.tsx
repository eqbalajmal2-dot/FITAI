import { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import {
  Droplets,
  Plus,
  Minus,
  Flame,
  Clock,
  Dumbbell,
  TrendingUp,
  Calendar,
  Activity,
  Trash2,
  Award,
} from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { Card, Badge, SectionHeader } from '@/components/ui';
import { COLORS, SPACING, FONT_SIZES, BORDER_RADIUS } from '@/constants/theme';
import { WorkoutHistoryItem, WaterIntake } from '@/types/database';

const screenWidth = Dimensions.get('window').width;
const WATER_GOAL = 8;

export default function ProgressScreen() {
  const { user, profile } = useAuth();
  const [waterIntake, setWaterIntake] = useState<WaterIntake | null>(null);
  const [workouts, setWorkouts] = useState<WorkoutHistoryItem[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [weeklyData, setWeeklyData] = useState<{ day: string; calories: number; minutes: number }[]>([]);

  const loadData = async () => {
    if (!user) return;
    const today = new Date().toISOString().split('T')[0];

    const [waterRes, workoutsRes] = await Promise.all([
      supabase
        .from('water_intake')
        .select('*')
        .eq('user_id', user.id)
        .eq('intake_date', today)
        .maybeSingle(),
      supabase
        .from('workout_history')
        .select('*')
        .eq('user_id', user.id)
        .order('completed_at', { ascending: false }),
    ]);

    if (waterRes.data) setWaterIntake(waterRes.data as WaterIntake);
    else setWaterIntake(null);
    if (workoutsRes.data) {
      setWorkouts(workoutsRes.data as WorkoutHistoryItem[]);
      buildWeeklyData(workoutsRes.data as WorkoutHistoryItem[]);
    }
  };

  const buildWeeklyData = (allWorkouts: WorkoutHistoryItem[]) => {
    const days: { day: string; calories: number; minutes: number }[] = [];
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const now = new Date();
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const dayWorkouts = allWorkouts.filter((w) => w.completed_at.startsWith(dateStr));
      days.push({
        day: dayNames[d.getDay()],
        calories: dayWorkouts.reduce((sum, w) => sum + w.calories_burned, 0),
        minutes: dayWorkouts.reduce((sum, w) => sum + w.duration_minutes, 0),
      });
    }
    setWeeklyData(days);
  };

  useFocusEffect(useCallback(() => {
    loadData();
  }, [user]));

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const updateWater = async (delta: number) => {
    if (!user) return;
    const today = new Date().toISOString().split('T')[0];
    const newGlasses = Math.max(0, (waterIntake?.glasses || 0) + delta);

    if (waterIntake) {
      const { data, error } = await supabase
        .from('water_intake')
        .update({ glasses: newGlasses })
        .eq('id', waterIntake.id)
        .select('*')
        .maybeSingle();
      if (data) setWaterIntake(data as WaterIntake);
    } else {
      const { data, error } = await supabase
        .from('water_intake')
        .insert({ user_id: user.id, glasses: newGlasses, intake_date: today })
        .select('*')
        .maybeSingle();
      if (data) setWaterIntake(data as WaterIntake);
    }
  };

  const deleteWorkout = async (id: string) => {
    await supabase.from('workout_history').delete().eq('id', id);
    setWorkouts((prev) => prev.filter((w) => w.id !== id));
  };

  const waterGlasses = waterIntake?.glasses || 0;
  const waterPercent = Math.min(waterGlasses / WATER_GOAL, 1);
  const maxCalories = Math.max(...weeklyData.map((d) => d.calories), 1);
  const totalCalories = workouts.reduce((sum, w) => sum + w.calories_burned, 0);
  const totalMinutes = workouts.reduce((sum, w) => sum + w.duration_minutes, 0);
  const avgDuration = workouts.length > 0 ? Math.round(totalMinutes / workouts.length) : 0;

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={COLORS.neonGreen} />}
      >
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Progress</Text>
          <Text style={styles.headerSubtitle}>Track your fitness journey</Text>
        </View>

        {/* Summary Stats */}
        <View style={styles.summaryRow}>
          <Card style={styles.summaryCard}>
            <View style={styles.summaryIconBox}>
              <Dumbbell color={COLORS.neonGreen} size={18} strokeWidth={2.5} />
            </View>
            <Text style={styles.summaryValue}>{workouts.length}</Text>
            <Text style={styles.summaryLabel}>Total Workouts</Text>
          </Card>
          <Card style={styles.summaryCard}>
            <View style={styles.summaryIconBox}>
              <Flame color={COLORS.warning} size={18} strokeWidth={2.5} />
            </View>
            <Text style={styles.summaryValue}>{totalCalories}</Text>
            <Text style={styles.summaryLabel}>Calories Burned</Text>
          </Card>
          <Card style={styles.summaryCard}>
            <View style={styles.summaryIconBox}>
              <Clock color={COLORS.accentBlue} size={18} strokeWidth={2.5} />
            </View>
            <Text style={styles.summaryValue}>{avgDuration}</Text>
            <Text style={styles.summaryLabel}>Avg Minutes</Text>
          </Card>
        </View>

        {/* Weekly Chart */}
        <View style={styles.sectionSpacing}>
          <SectionHeader title="This Week" subtitle="Calories burned per day" />
          <Card style={styles.chartCard}>
            <View style={styles.chartRow}>
              {weeklyData.map((d, i) => {
                const height = maxCalories > 0 ? (d.calories / maxCalories) * 100 : 0;
                return (
                  <View key={i} style={styles.chartBarContainer}>
                    <View style={styles.chartBarBg}>
                      {height > 0 ? (
                        <LinearGradient
                          colors={[COLORS.neonGreen, COLORS.neonGreenDim]}
                          start={{ x: 0, y: 1 }}
                          end={{ x: 0, y: 0 }}
                          style={[styles.chartBarFill, { height: `${Math.max(height, 4)}%` }]}
                        />
                      ) : (
                        <View style={styles.chartBarEmpty} />
                      )}
                    </View>
                    <Text style={styles.chartDayLabel}>{d.day}</Text>
                    {d.calories > 0 && (
                      <Text style={styles.chartCalories}>{d.calories}</Text>
                    )}
                  </View>
                );
              })}
            </View>
          </Card>
        </View>

        {/* Water Tracker */}
        <View style={styles.sectionSpacing}>
          <SectionHeader title="Water Tracker" subtitle={`Goal: ${WATER_GOAL} glasses per day`} />
          <Card style={styles.waterCard}>
            <View style={styles.waterTopRow}>
              <View style={styles.waterLeftSection}>
                <View style={styles.waterBigIcon}>
                  <Droplets color={COLORS.accentBlue} size={28} strokeWidth={2.5} />
                </View>
                <View>
                  <Text style={styles.waterCountText}>{waterGlasses}/{WATER_GOAL}</Text>
                  <Text style={styles.waterSubText}>glasses today</Text>
                </View>
              </View>
              <View style={styles.waterControls}>
                <TouchableOpacity
                  onPress={() => updateWater(-1)}
                  style={[styles.waterBtn, waterGlasses === 0 && styles.waterBtnDisabled]}
                  activeOpacity={0.7}
                  disabled={waterGlasses === 0}
                >
                  <Minus color={waterGlasses === 0 ? COLORS.grayDark : COLORS.accentBlue} size={20} strokeWidth={2.5} />
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => updateWater(1)}
                  style={styles.waterBtn}
                  activeOpacity={0.7}
                >
                  <Plus color={COLORS.accentBlue} size={20} strokeWidth={2.5} />
                </TouchableOpacity>
              </View>
            </View>
            <View style={styles.waterGlassesRow}>
              {Array.from({ length: WATER_GOAL }).map((_, i) => (
                <View
                  key={i}
                  style={[styles.waterGlass, i < waterGlasses && styles.waterGlassFilled]}
                >
                  {i < waterGlasses && (
                    <Droplets color={COLORS.accentBlue} size={12} strokeWidth={2.5} />
                  )}
                </View>
              ))}
            </View>
            <View style={styles.waterBarBg}>
              <LinearGradient
                colors={[COLORS.accentBlue, '#0080FF']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={[styles.waterBarFill, { width: `${waterPercent * 100}%` }]}
              />
            </View>
            {waterGlasses >= WATER_GOAL && (
              <View style={styles.waterGoalReached}>
                <Award color={COLORS.neonGreen} size={16} strokeWidth={2.5} />
                <Text style={styles.waterGoalText}>Daily goal reached! Great job!</Text>
              </View>
            )}
          </Card>
        </View>

        {/* Workout History */}
        <View style={styles.sectionSpacing}>
          <SectionHeader title="Workout History" subtitle={`${workouts.length} total sessions`} />
          {workouts.length > 0 ? (
            workouts.map((w) => (
              <Card key={w.id} style={styles.historyCard}>
                <View style={styles.historyLeft}>
                  <View style={styles.historyIconBox}>
                    <Activity color={COLORS.neonGreen} size={18} strokeWidth={2.5} />
                  </View>
                  <View style={styles.historyInfo}>
                    <Text style={styles.historyName}>{w.workout_name}</Text>
                    <Text style={styles.historyDate}>
                      {new Date(w.completed_at).toLocaleDateString('en-US', {
                        weekday: 'short',
                        month: 'short',
                        day: 'numeric',
                        hour: 'numeric',
                        minute: '2-digit',
                      })}
                    </Text>
                    <View style={styles.historyStatsRow}>
                      <View style={styles.historyStat}>
                        <Clock color={COLORS.gray} size={11} strokeWidth={2} />
                        <Text style={styles.historyStatText}>{w.duration_minutes} min</Text>
                      </View>
                      <View style={styles.historyStat}>
                        <Flame color={COLORS.gray} size={11} strokeWidth={2} />
                        <Text style={styles.historyStatText}>{w.calories_burned} cal</Text>
                      </View>
                    </View>
                  </View>
                </View>
                <View style={styles.historyRight}>
                  <Badge text={w.difficulty} />
                  <TouchableOpacity onPress={() => deleteWorkout(w.id)} style={styles.deleteBtn}>
                    <Trash2 color={COLORS.gray} size={16} strokeWidth={2} />
                  </TouchableOpacity>
                </View>
              </Card>
            ))
          ) : (
            <Card style={styles.emptyCard}>
              <Calendar color={COLORS.gray} size={32} strokeWidth={1.5} />
              <Text style={styles.emptyText}>No workouts logged yet</Text>
              <Text style={styles.emptySubtext}>Complete a workout to see your history here</Text>
            </Card>
          )}
        </View>

        <View style={{ height: 90 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.black,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: SPACING.lg,
  },
  header: {
    marginBottom: SPACING.xl,
  },
  headerTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.xxxl,
    color: COLORS.white,
  },
  headerSubtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.sm,
    color: COLORS.gray,
    marginTop: 2,
  },
  summaryRow: {
    flexDirection: 'row',
    gap: SPACING.sm,
    marginBottom: SPACING.lg,
  },
  summaryCard: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: SPACING.md,
  },
  summaryIconBox: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: COLORS.cardBgLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: SPACING.xs,
  },
  summaryValue: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.xl,
    color: COLORS.white,
  },
  summaryLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.gray,
    marginTop: 2,
    textAlign: 'center',
  },
  sectionSpacing: {
    marginBottom: SPACING.lg,
  },
  chartCard: {
    paddingVertical: SPACING.lg,
  },
  chartRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    height: 140,
    paddingHorizontal: SPACING.xs,
  },
  chartBarContainer: {
    flex: 1,
    alignItems: 'center',
    marginHorizontal: 2,
  },
  chartBarBg: {
    width: '100%',
    height: 100,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  chartBarFill: {
    width: '70%',
    borderRadius: 4,
    minHeight: 4,
  },
  chartBarEmpty: {
    width: '70%',
    height: 3,
    backgroundColor: COLORS.cardBgLight,
    borderRadius: 2,
  },
  chartDayLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.gray,
    marginTop: SPACING.xs,
  },
  chartCalories: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 9,
    color: COLORS.neonGreen,
    marginTop: 2,
  },
  waterCard: {},
  waterTopRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.md,
  },
  waterLeftSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.md,
  },
  waterBigIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#0A1A2A',
    alignItems: 'center',
    justifyContent: 'center',
  },
  waterCountText: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.xl,
    color: COLORS.white,
  },
  waterSubText: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.gray,
    marginTop: 2,
  },
  waterControls: {
    flexDirection: 'row',
    gap: SPACING.sm,
  },
  waterBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#0A1A2A',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: COLORS.accentBlue + '40',
  },
  waterBtnDisabled: {
    opacity: 0.4,
  },
  waterGlassesRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: SPACING.md,
    gap: SPACING.xs,
  },
  waterGlass: {
    flex: 1,
    height: 32,
    borderRadius: BORDER_RADIUS.sm,
    backgroundColor: COLORS.cardBgLight,
    borderWidth: 1,
    borderColor: COLORS.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  waterGlassFilled: {
    backgroundColor: COLORS.accentBlue + '20',
    borderColor: COLORS.accentBlue + '60',
  },
  waterBarBg: {
    height: 8,
    backgroundColor: COLORS.cardBgLight,
    borderRadius: 4,
    overflow: 'hidden',
  },
  waterBarFill: {
    height: '100%',
    borderRadius: 4,
  },
  waterGoalReached: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.xs,
    marginTop: SPACING.md,
    justifyContent: 'center',
  },
  waterGoalText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.sm,
    color: COLORS.neonGreen,
  },
  historyCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.sm,
  },
  historyLeft: {
    flexDirection: 'row',
    gap: SPACING.md,
    flex: 1,
  },
  historyIconBox: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: COLORS.neonGreen + '15',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
  historyInfo: {
    flex: 1,
  },
  historyName: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.md,
    color: COLORS.white,
  },
  historyDate: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.gray,
    marginTop: 2,
  },
  historyStatsRow: {
    flexDirection: 'row',
    gap: SPACING.md,
    marginTop: SPACING.xs,
  },
  historyStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.xs,
  },
  historyStatText: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.gray,
  },
  historyRight: {
    alignItems: 'flex-end',
    gap: SPACING.sm,
  },
  deleteBtn: {
    padding: SPACING.xs,
  },
  emptyCard: {
    alignItems: 'center',
    paddingVertical: SPACING.xxl,
  },
  emptyText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.md,
    color: COLORS.white,
    marginTop: SPACING.md,
  },
  emptySubtext: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.sm,
    color: COLORS.gray,
    marginTop: SPACING.xs,
    textAlign: 'center',
  },
});

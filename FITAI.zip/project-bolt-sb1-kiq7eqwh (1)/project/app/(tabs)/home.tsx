import { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect, useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Dumbbell, Bot, Droplets, Flame, Clock, TrendingUp, ChevronRight, Target, Activity, Zap } from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { Card, Badge } from '@/components/ui';
import { COLORS, SPACING, FONT_SIZES, BORDER_RADIUS } from '@/constants/theme';
import { WorkoutHistoryItem, WaterIntake, WorkoutPlan } from '@/types/database';

export default function HomeScreen() {
  const { profile, user } = useAuth();
  const router = useRouter();
  const [recentWorkouts, setRecentWorkouts] = useState<WorkoutHistoryItem[]>([]);
  const [waterIntake, setWaterIntake] = useState<WaterIntake | null>(null);
  const [recommendedPlans, setRecommendedPlans] = useState<WorkoutPlan[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState({ totalWorkouts: 0, totalCalories: 0, totalMinutes: 0 });

  const loadData = async () => {
    if (!user) return;

    const [workoutsRes, waterRes, plansRes] = await Promise.all([
      supabase
        .from('workout_history')
        .select('*')
        .eq('user_id', user.id)
        .order('completed_at', { ascending: false })
        .limit(3),
      supabase
        .from('water_intake')
        .select('*')
        .eq('user_id', user.id)
        .eq('intake_date', new Date().toISOString().split('T')[0])
        .maybeSingle(),
      supabase
        .from('workout_plans')
        .select('*')
        .limit(3),
    ]);

    if (workoutsRes.data) setRecentWorkouts(workoutsRes.data as WorkoutHistoryItem[]);
    if (waterRes.data) setWaterIntake(waterRes.data as WaterIntake);
    if (plansRes.data) setRecommendedPlans(plansRes.data as WorkoutPlan[]);

    // Calculate stats from all workouts
    const allWorkoutsRes = await supabase
      .from('workout_history')
      .select('duration_minutes, calories_burned')
      .eq('user_id', user.id);

    if (allWorkoutsRes.data) {
      const totalCalories = allWorkoutsRes.data.reduce((sum, w) => sum + (w.calories_burned || 0), 0);
      const totalMinutes = allWorkoutsRes.data.reduce((sum, w) => sum + (w.duration_minutes || 0), 0);
      setStats({
        totalWorkouts: allWorkoutsRes.data.length,
        totalCalories,
        totalMinutes,
      });
    }
  };

  useFocusEffect(useCallback(() => {
    loadData();
  }, [user]));

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const greeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  const firstName = profile?.full_name?.split(' ')[0] || 'Athlete';
  const waterGlasses = waterIntake?.glasses || 0;
  const waterGoal = 8;
  const waterPercent = Math.min(waterGlasses / waterGoal, 1);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={COLORS.neonGreen} />}
      >
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>{greeting()},</Text>
            <Text style={styles.userName}>{firstName}</Text>
          </View>
          <TouchableOpacity
            style={styles.avatarContainer}
            onPress={() => router.push('/(tabs)/profile')}
          >
            <LinearGradient
              colors={[COLORS.neonGreen, COLORS.neonGreenDim]}
              style={styles.avatar}
            >
              <Text style={styles.avatarText}>{firstName.charAt(0).toUpperCase()}</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Quick Stats */}
        <View style={styles.statsRow}>
          <Card style={styles.statCard}>
            <View style={styles.statIconBox}>
              <Dumbbell color={COLORS.neonGreen} size={18} strokeWidth={2.5} />
            </View>
            <Text style={styles.statValue}>{stats.totalWorkouts}</Text>
            <Text style={styles.statLabel}>Workouts</Text>
          </Card>
          <Card style={styles.statCard}>
            <View style={styles.statIconBox}>
              <Flame color={COLORS.warning} size={18} strokeWidth={2.5} />
            </View>
            <Text style={styles.statValue}>{stats.totalCalories}</Text>
            <Text style={styles.statLabel}>Calories</Text>
          </Card>
          <Card style={styles.statCard}>
            <View style={styles.statIconBox}>
              <Clock color={COLORS.accentBlue} size={18} strokeWidth={2.5} />
            </View>
            <Text style={styles.statValue}>{stats.totalMinutes}</Text>
            <Text style={styles.statLabel}>Minutes</Text>
          </Card>
        </View>

        {/* Water Tracker Quick View */}
        <Card style={styles.waterCard}>
          <View style={styles.waterHeader}>
            <View style={styles.waterLeft}>
              <View style={styles.waterIconBox}>
                <Droplets color={COLORS.accentBlue} size={20} strokeWidth={2.5} />
              </View>
              <View>
                <Text style={styles.waterTitle}>Water Intake</Text>
                <Text style={styles.waterSubtitle}>{waterGlasses} of {waterGoal} glasses</Text>
              </View>
            </View>
            <TouchableOpacity onPress={() => router.push('/(tabs)/progress')}>
              <ChevronRight color={COLORS.gray} size={22} />
            </TouchableOpacity>
          </View>
          <View style={styles.waterBarBg}>
            <LinearGradient
              colors={[COLORS.accentBlue, '#0080FF']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={[styles.waterBarFill, { width: `${waterPercent * 100}%` }]}
            />
          </View>
        </Card>

        {/* Quick Actions */}
        <View style={styles.quickActions}>
          <TouchableOpacity
            style={styles.quickActionBtn}
            onPress={() => router.push('/(tabs)/ai-coach')}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={['#0A2218', COLORS.cardBg]}
              style={styles.quickActionGradient}
            >
              <View style={styles.quickActionIconBox}>
                <Bot color={COLORS.neonGreen} size={24} strokeWidth={2.5} />
              </View>
              <Text style={styles.quickActionTitle}>Ask AI Coach</Text>
              <Text style={styles.quickActionSubtitle}>Get instant advice</Text>
            </LinearGradient>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.quickActionBtn}
            onPress={() => router.push('/(tabs)/workouts')}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={['#0A2218', COLORS.cardBg]}
              style={styles.quickActionGradient}
            >
              <View style={styles.quickActionIconBox}>
                <Zap color={COLORS.neonGreen} size={24} strokeWidth={2.5} />
              </View>
              <Text style={styles.quickActionTitle}>Start Workout</Text>
              <Text style={styles.quickActionSubtitle}>Browse plans</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Recommended Plans */}
        <View style={styles.sectionSpacing}>
          <View style={styles.sectionHeaderRow}>
            <Text style={styles.sectionTitle}>Recommended Plans</Text>
            <TouchableOpacity onPress={() => router.push('/(tabs)/workouts')}>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          {recommendedPlans.map((plan) => (
            <Card key={plan.id} style={styles.planCard} onPress={() => router.push({ pathname: '/(tabs)/workouts', params: { planId: plan.id } })}>
              <View style={styles.planLeft}>
                <View style={styles.planIconBox}>
                  <Dumbbell color={COLORS.neonGreen} size={20} strokeWidth={2.5} />
                </View>
                <View style={styles.planInfo}>
                  <Text style={styles.planName}>{plan.name}</Text>
                  <View style={styles.planMetaRow}>
                    <Clock color={COLORS.gray} size={12} strokeWidth={2} />
                    <Text style={styles.planMetaText}>{plan.duration_minutes} min</Text>
                    <Flame color={COLORS.gray} size={12} strokeWidth={2} />
                    <Text style={styles.planMetaText}>{plan.calories_estimate} cal</Text>
                  </View>
                </View>
              </View>
              <Badge text={plan.difficulty} />
            </Card>
          ))}
        </View>

        {/* Recent Workouts */}
        <View style={styles.sectionSpacing}>
          <View style={styles.sectionHeaderRow}>
            <Text style={styles.sectionTitle}>Recent Activity</Text>
            <TouchableOpacity onPress={() => router.push('/(tabs)/progress')}>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          {recentWorkouts.length > 0 ? (
            recentWorkouts.map((w) => (
              <Card key={w.id} style={styles.workoutHistoryCard}>
                <View style={styles.workoutHistoryLeft}>
                  <View style={styles.workoutHistoryIcon}>
                    <Activity color={COLORS.neonGreen} size={18} strokeWidth={2.5} />
                  </View>
                  <View>
                    <Text style={styles.workoutHistoryName}>{w.workout_name}</Text>
                    <Text style={styles.workoutHistoryDate}>
                      {new Date(w.completed_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    </Text>
                  </View>
                </View>
                <View style={styles.workoutHistoryRight}>
                  <Text style={styles.workoutHistoryCalories}>{w.calories_burned} cal</Text>
                  <Text style={styles.workoutHistoryDuration}>{w.duration_minutes} min</Text>
                </View>
              </Card>
            ))
          ) : (
            <Card style={styles.emptyCard}>
              <Text style={styles.emptyText}>No workouts yet. Start your first session!</Text>
              <TouchableOpacity onPress={() => router.push('/(tabs)/workouts')}>
                <Text style={styles.emptyLink}>Browse Workouts</Text>
              </TouchableOpacity>
            </Card>
          )}
        </View>

        {/* Fitness Goal Card */}
        <View style={styles.sectionSpacing}>
          <Card style={styles.goalCard}>
            <View style={styles.goalHeader}>
              <Target color={COLORS.neonGreen} size={20} strokeWidth={2.5} />
              <Text style={styles.goalTitle}>Your Fitness Goal</Text>
            </View>
            <Text style={styles.goalText}>{profile?.fitness_goal || 'General fitness'}</Text>
            <View style={styles.goalFooter}>
              <Badge text={profile?.fitness_level || 'beginner'} />
              <TouchableOpacity onPress={() => router.push('/(tabs)/profile')}>
                <Text style={styles.goalEdit}>Edit Profile</Text>
              </TouchableOpacity>
            </View>
          </Card>
        </View>

        <View style={{ height: 90 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.black,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: SPACING.lg,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.xl,
  },
  greeting: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.md,
    color: COLORS.gray,
  },
  userName: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.xxl,
    color: COLORS.white,
    marginTop: 2,
  },
  avatarContainer: {},
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.lg,
    color: COLORS.black,
  },
  statsRow: {
    flexDirection: 'row',
    gap: SPACING.sm,
    marginBottom: SPACING.md,
  },
  statCard: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: SPACING.md,
  },
  statIconBox: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: COLORS.cardBgLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: SPACING.xs,
  },
  statValue: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.xl,
    color: COLORS.white,
  },
  statLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.gray,
    marginTop: 2,
  },
  waterCard: {
    marginBottom: SPACING.lg,
  },
  waterHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.md,
  },
  waterLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
  },
  waterIconBox: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#0A1A2A',
    alignItems: 'center',
    justifyContent: 'center',
  },
  waterTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.md,
    color: COLORS.white,
  },
  waterSubtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.sm,
    color: COLORS.gray,
    marginTop: 2,
  },
  waterBarBg: {
    height: 8,
    backgroundColor: COLORS.cardBgLight,
    borderRadius: 4,
    overflow: 'hidden',
  },
  waterBarFill: {
    height: '100%',
    borderRadius: 4,
  },
  quickActions: {
    flexDirection: 'row',
    gap: SPACING.sm,
    marginBottom: SPACING.lg,
  },
  quickActionBtn: {
    flex: 1,
    borderRadius: BORDER_RADIUS.lg,
    overflow: 'hidden',
  },
  quickActionGradient: {
    padding: SPACING.md,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: BORDER_RADIUS.lg,
  },
  quickActionIconBox: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: COLORS.neonGreen + '15',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: SPACING.sm,
  },
  quickActionTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.md,
    color: COLORS.white,
  },
  quickActionSubtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.gray,
    marginTop: 2,
  },
  sectionSpacing: {
    marginBottom: SPACING.lg,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.md,
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.lg,
    color: COLORS.white,
  },
  seeAllText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.sm,
    color: COLORS.neonGreen,
  },
  planCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: SPACING.md,
    marginBottom: SPACING.sm,
  },
  planLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.md,
    flex: 1,
  },
  planIconBox: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: COLORS.neonGreen + '15',
    alignItems: 'center',
    justifyContent: 'center',
  },
  planInfo: {
    flex: 1,
  },
  planName: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.md,
    color: COLORS.white,
  },
  planMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.xs,
    marginTop: 4,
  },
  planMetaText: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.gray,
    marginRight: SPACING.sm,
  },
  workoutHistoryCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: SPACING.md,
    marginBottom: SPACING.sm,
  },
  workoutHistoryLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.md,
    flex: 1,
  },
  workoutHistoryIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: COLORS.neonGreen + '15',
    alignItems: 'center',
    justifyContent: 'center',
  },
  workoutHistoryName: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.md,
    color: COLORS.white,
  },
  workoutHistoryDate: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.gray,
    marginTop: 2,
  },
  workoutHistoryRight: {
    alignItems: 'flex-end',
  },
  workoutHistoryCalories: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.sm,
    color: COLORS.warning,
  },
  workoutHistoryDuration: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.gray,
    marginTop: 2,
  },
  emptyCard: {
    alignItems: 'center',
    paddingVertical: SPACING.xl,
  },
  emptyText: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.md,
    color: COLORS.gray,
    marginBottom: SPACING.sm,
  },
  emptyLink: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.md,
    color: COLORS.neonGreen,
  },
  goalCard: {},
  goalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    marginBottom: SPACING.sm,
  },
  goalTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.md,
    color: COLORS.white,
  },
  goalText: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.lg,
    color: COLORS.neonGreen,
    marginBottom: SPACING.md,
  },
  goalFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  goalEdit: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.sm,
    color: COLORS.neonGreen,
  },
});

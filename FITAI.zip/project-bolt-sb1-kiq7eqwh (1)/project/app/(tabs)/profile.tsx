import { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  TextInput,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import {
  User as UserIcon,
  Target,
  Dumbbell,
  LogOut,
  Edit2,
  Check,
  X,
  Award,
  Flame,
  Clock,
  Mail,
  Cake,
  Scale,
  Ruler,
} from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { Card, Badge, NeonButton, Input } from '@/components/ui';
import { COLORS, SPACING, FONT_SIZES, BORDER_RADIUS } from '@/constants/theme';
import { WorkoutHistoryItem } from '@/types/database';

export default function ProfileScreen() {
  const { user, profile, signOut, updateProfile, refreshProfile } = useAuth();
  const [editing, setEditing] = useState(false);
  const [fullName, setFullName] = useState(profile?.full_name || '');
  const [age, setAge] = useState(String(profile?.age || ''));
  const [weightKg, setWeightKg] = useState(String(profile?.weight_kg || ''));
  const [heightCm, setHeightCm] = useState(String(profile?.height_cm || ''));
  const [fitnessLevel, setFitnessLevel] = useState(profile?.fitness_level || 'beginner');
  const [fitnessGoal, setFitnessGoal] = useState(profile?.fitness_goal || 'general fitness');
  const [saving, setSaving] = useState(false);
  const [stats, setStats] = useState({ totalWorkouts: 0, totalCalories: 0, totalMinutes: 0 });
  const [refreshing, setRefreshing] = useState(false);

  useFocusEffect(useCallback(() => {
    if (user) {
      supabase
        .from('workout_history')
        .select('duration_minutes, calories_burned')
        .eq('user_id', user.id)
        .then(({ data }) => {
          if (data) {
            setStats({
              totalWorkouts: data.length,
              totalCalories: data.reduce((s, w) => s + w.calories_burned, 0),
              totalMinutes: data.reduce((s, w) => s + w.duration_minutes, 0),
            });
          }
        });
    }
    if (profile) {
      setFullName(profile.full_name);
      setAge(String(profile.age || ''));
      setWeightKg(String(profile.weight_kg || ''));
      setHeightCm(String(profile.height_cm || ''));
      setFitnessLevel(profile.fitness_level);
      setFitnessGoal(profile.fitness_goal);
    }
  }, [user, profile]));

  const handleSave = async () => {
    setSaving(true);
    const { error } = await updateProfile({
      full_name: fullName,
      age: age ? parseInt(age) : null,
      weight_kg: weightKg ? parseFloat(weightKg) : null,
      height_cm: heightCm ? parseFloat(heightCm) : null,
      fitness_level: fitnessLevel as 'beginner' | 'intermediate' | 'advanced',
      fitness_goal: fitnessGoal,
    });
    setSaving(false);
    if (error) {
      Alert.alert('Error', error);
    } else {
      setEditing(false);
    }
  };

  const handleCancel = () => {
    if (profile) {
      setFullName(profile.full_name);
      setAge(String(profile.age || ''));
      setWeightKg(String(profile.weight_kg || ''));
      setHeightCm(String(profile.height_cm || ''));
      setFitnessLevel(profile.fitness_level);
      setFitnessGoal(profile.fitness_goal);
    }
    setEditing(false);
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await refreshProfile();
    setRefreshing(false);
  };

  const firstName = profile?.full_name?.split(' ')[0] || 'Athlete';
  const initial = firstName.charAt(0).toUpperCase();

  const goals = ['general fitness', 'lose weight', 'build muscle', 'increase endurance', 'improve strength'];
  const levels: Array<'beginner' | 'intermediate' | 'advanced'> = ['beginner', 'intermediate', 'advanced'];

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={COLORS.neonGreen} />}
      >
        {/* Profile Header */}
        <View style={styles.profileHeader}>
          <LinearGradient
            colors={[COLORS.neonGreen, COLORS.neonGreenDim]}
            style={styles.avatarLarge}
          >
            <Text style={styles.avatarLargeText}>{initial}</Text>
          </LinearGradient>
          <Text style={styles.profileName}>{profile?.full_name || 'Athlete'}</Text>
          <Text style={styles.profileEmail}>{user?.email || ''}</Text>
          <View style={styles.profileBadges}>
            <Badge text={profile?.fitness_level || 'beginner'} />
            <Badge text={profile?.fitness_goal || 'general fitness'} color={COLORS.accentBlue} />
          </View>
        </View>

        {/* Quick Stats */}
        <View style={styles.statsRow}>
          <Card style={styles.statCard}>
            <Dumbbell color={COLORS.neonGreen} size={18} strokeWidth={2.5} />
            <Text style={styles.statValue}>{stats.totalWorkouts}</Text>
            <Text style={styles.statLabel}>Workouts</Text>
          </Card>
          <Card style={styles.statCard}>
            <Flame color={COLORS.warning} size={18} strokeWidth={2.5} />
            <Text style={styles.statValue}>{stats.totalCalories}</Text>
            <Text style={styles.statLabel}>Calories</Text>
          </Card>
          <Card style={styles.statCard}>
            <Clock color={COLORS.accentBlue} size={18} strokeWidth={2.5} />
            <Text style={styles.statValue}>{stats.totalMinutes}</Text>
            <Text style={styles.statLabel}>Minutes</Text>
          </Card>
        </View>

        {/* Edit / Profile Info */}
        <View style={styles.sectionSpacing}>
          <View style={styles.sectionHeaderRow}>
            <Text style={styles.sectionTitle}>Profile Information</Text>
            {!editing ? (
              <TouchableOpacity onPress={() => setEditing(true)} style={styles.editBtn}>
                <Edit2 color={COLORS.neonGreen} size={16} strokeWidth={2.5} />
                <Text style={styles.editBtnText}>Edit</Text>
              </TouchableOpacity>
            ) : (
              <View style={styles.editActions}>
                <TouchableOpacity onPress={handleCancel} style={styles.cancelBtn}>
                  <X color={COLORS.gray} size={16} strokeWidth={2.5} />
                </TouchableOpacity>
                <TouchableOpacity onPress={handleSave} style={styles.saveBtn} disabled={saving}>
                  <Check color={COLORS.neonGreen} size={16} strokeWidth={2.5} />
                  <Text style={styles.saveBtnText}>{saving ? 'Saving...' : 'Save'}</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>

          <Card style={styles.infoCard}>
            {editing ? (
              <View>
                <Input label="Full Name" value={fullName} onChangeText={setFullName} placeholder="Your full name" autoCapitalize="words" />
                <Input label="Age" value={age} onChangeText={setAge} placeholder="25" keyboardType="numeric" />
                <Input label="Weight (kg)" value={weightKg} onChangeText={setWeightKg} placeholder="70" keyboardType="numeric" />
                <Input label="Height (cm)" value={heightCm} onChangeText={setHeightCm} placeholder="175" keyboardType="numeric" />

                <Text style={styles.inputLabel}>Fitness Level</Text>
                <View style={styles.chipRow}>
                  {levels.map((level) => (
                    <TouchableOpacity
                      key={level}
                      onPress={() => setFitnessLevel(level)}
                      style={[styles.chip, fitnessLevel === level && styles.chipActive]}
                      activeOpacity={0.7}
                    >
                      <Text style={[styles.chipText, fitnessLevel === level && styles.chipTextActive]}>
                        {level.charAt(0).toUpperCase() + level.slice(1)}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>

                <Text style={styles.inputLabel}>Fitness Goal</Text>
                <View style={styles.chipRow}>
                  {goals.map((goal) => (
                    <TouchableOpacity
                      key={goal}
                      onPress={() => setFitnessGoal(goal)}
                      style={[styles.chip, fitnessGoal === goal && styles.chipActive]}
                      activeOpacity={0.7}
                    >
                      <Text style={[styles.chipText, fitnessGoal === goal && styles.chipTextActive]}>
                        {goal}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            ) : (
              <View>
                <InfoRow icon={<UserIcon size={16} color={COLORS.neonGreen} strokeWidth={2.5} />} label="Full Name" value={profile?.full_name || 'Not set'} />
                <InfoRow icon={<Mail size={16} color={COLORS.neonGreen} strokeWidth={2.5} />} label="Email" value={user?.email || 'Not set'} />
                <InfoRow icon={<Cake size={16} color={COLORS.neonGreen} strokeWidth={2.5} />} label="Age" value={profile?.age ? `${profile.age} years` : 'Not set'} />
                <InfoRow icon={<Scale size={16} color={COLORS.neonGreen} strokeWidth={2.5} />} label="Weight" value={profile?.weight_kg ? `${profile.weight_kg} kg` : 'Not set'} />
                <InfoRow icon={<Ruler size={16} color={COLORS.neonGreen} strokeWidth={2.5} />} label="Height" value={profile?.height_cm ? `${profile.height_cm} cm` : 'Not set'} />
                <InfoRow icon={<Target size={16} color={COLORS.neonGreen} strokeWidth={2.5} />} label="Fitness Level" value={(profile?.fitness_level || 'beginner').charAt(0).toUpperCase() + (profile?.fitness_level || 'beginner').slice(1)} />
                <InfoRow icon={<Award size={16} color={COLORS.neonGreen} strokeWidth={2.5} />} label="Fitness Goal" value={(profile?.fitness_goal || 'general fitness').charAt(0).toUpperCase() + (profile?.fitness_goal || 'general fitness').slice(1)} lastItem />
              </View>
            )}
          </Card>
        </View>

        {/* Sign Out */}
        <View style={{ marginTop: SPACING.lg }}>
          <TouchableOpacity onPress={signOut} activeOpacity={0.8} style={styles.signOutBtn}>
            <LogOut color={COLORS.error} size={20} strokeWidth={2.5} />
            <Text style={styles.signOutText}>Sign Out</Text>
          </TouchableOpacity>
        </View>

        {/* App Info */}
        <View style={styles.appInfoContainer}>
          <Text style={styles.appInfoText}>FITAI v1.0.0</Text>
          <Text style={styles.appInfoSubtext}>Your AI Personal Gym Coach</Text>
        </View>

        <View style={{ height: 90 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

function InfoRow({ icon, label, value, lastItem }: { icon: React.ReactNode; label: string; value: string; lastItem?: boolean }) {
  return (
    <View style={[styles.infoRow, !lastItem && styles.infoRowBorder]}>
      <View style={styles.infoRowLeft}>
        {icon}
        <Text style={styles.infoRowLabel}>{label}</Text>
      </View>
      <Text style={styles.infoRowValue}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.black,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: SPACING.lg,
  },
  profileHeader: {
    alignItems: 'center',
    paddingVertical: SPACING.xl,
  },
  avatarLarge: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: SPACING.md,
  },
  avatarLargeText: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.xxxl,
    color: COLORS.black,
  },
  profileName: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.xxl,
    color: COLORS.white,
  },
  profileEmail: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.sm,
    color: COLORS.gray,
    marginTop: 2,
  },
  profileBadges: {
    flexDirection: 'row',
    gap: SPACING.sm,
    marginTop: SPACING.md,
  },
  statsRow: {
    flexDirection: 'row',
    gap: SPACING.sm,
    marginBottom: SPACING.lg,
  },
  statCard: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: SPACING.md,
  },
  statValue: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.xl,
    color: COLORS.white,
    marginTop: SPACING.xs,
  },
  statLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.gray,
    marginTop: 2,
  },
  sectionSpacing: {
    marginBottom: SPACING.lg,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.md,
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.lg,
    color: COLORS.white,
  },
  editBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.xs,
    padding: SPACING.xs,
  },
  editBtnText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.sm,
    color: COLORS.neonGreen,
  },
  editActions: {
    flexDirection: 'row',
    gap: SPACING.md,
  },
  cancelBtn: {
    padding: SPACING.xs,
  },
  saveBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.xs,
    padding: SPACING.xs,
  },
  saveBtnText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.sm,
    color: COLORS.neonGreen,
  },
  infoCard: {},
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: SPACING.md,
  },
  infoRowBorder: {
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  infoRowLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.md,
  },
  infoRowLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.md,
    color: COLORS.grayLight,
  },
  infoRowValue: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.md,
    color: COLORS.white,
  },
  inputLabel: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.sm,
    color: COLORS.grayLight,
    marginBottom: SPACING.sm,
    marginTop: SPACING.md,
  },
  chipRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: SPACING.sm,
  },
  chip: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    borderRadius: BORDER_RADIUS.pill,
    backgroundColor: COLORS.cardBgLight,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  chipActive: {
    backgroundColor: COLORS.neonGreen + '15',
    borderColor: COLORS.neonGreen + '50',
  },
  chipText: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.sm,
    color: COLORS.gray,
  },
  chipTextActive: {
    color: COLORS.neonGreen,
    fontFamily: 'Inter-SemiBold',
  },
  signOutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: SPACING.sm,
    paddingVertical: SPACING.md + 2,
    borderRadius: BORDER_RADIUS.md,
    backgroundColor: COLORS.errorBg,
    borderWidth: 1,
    borderColor: COLORS.error + '33',
  },
  signOutText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.md,
    color: COLORS.error,
  },
  appInfoContainer: {
    alignItems: 'center',
    marginTop: SPACING.xl,
  },
  appInfoText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.xs,
    color: COLORS.gray,
  },
  appInfoSubtext: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.grayDark,
    marginTop: 2,
  },
});

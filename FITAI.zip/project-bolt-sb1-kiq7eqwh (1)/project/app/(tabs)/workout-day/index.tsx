import { useState, useEffect, useRef, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Dimensions,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter, useFocusEffect } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import {
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  Play,
  Pause,
  RotateCcw,
  Timer,
  Heart,
  Info,
  ShieldCheck,
  Flame,
  Dumbbell,
  Calendar,
  Target,
  ArrowRight,
} from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { Badge } from '@/components/ui';
import { COLORS, SPACING, FONT_SIZES, BORDER_RADIUS } from '@/constants/theme';
import { Exercise } from '@/types/database';
import { getExerciseImage, WEEKLY_PLAN } from '@/constants/exerciseImages';

const screenWidth = Dimensions.get('window').width;
const imageHeight = Math.min(Math.round(screenWidth * 0.56), 280);
const TAB_BAR_HEIGHT = 70;

export default function WorkoutDayScreen() {
  const { user } = useAuth();
  const router = useRouter();
  const params = useLocalSearchParams<{ dayIndex: string }>();
  const dayIndex = parseInt(params.dayIndex || '0', 10);
  const day = WEEKLY_PLAN[dayIndex] || WEEKLY_PLAN[0];

  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [completedExercises, setCompletedExercises] = useState<string[]>([]);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [timerRunning, setTimerRunning] = useState(false);
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const scrollRef = useRef<ScrollView | null>(null);

  useFocusEffect(useCallback(() => {
    supabase
      .from('exercises')
      .select('*')
      .then(({ data }) => {
        if (data) setExercises(data as Exercise[]);
      });
  }, []));

  useEffect(() => {
    if (timerRunning) {
      const id = setInterval(() => {
        setElapsedSeconds((prev) => prev + 1);
      }, 1000);
      intervalRef.current = id;
      return () => clearInterval(id);
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
  }, [timerRunning]);

  const getExerciseByName = (name: string) => exercises.find((e) => e.name === name);
  const dayExercises = day.exercises
    .map(getExerciseByName)
    .filter((e): e is Exercise => !!e);
  const isRestDay = dayExercises.length === 0;
  const totalCalories = dayExercises
    .filter((e) => completedExercises.includes(e.name))
    .reduce((sum, e) => sum + e.calories_per_set * 3, 0);

  const currentExercise = dayExercises[currentExerciseIndex];
  const isCurrentCompleted = currentExercise
    ? completedExercises.includes(currentExercise.name)
    : false;
  const isLastExercise = currentExerciseIndex === dayExercises.length - 1;
  const isFirstExercise = currentExerciseIndex === 0;

  const formatTime = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const toggleExercise = (name: string) => {
    setCompletedExercises((prev) =>
      prev.includes(name) ? prev.filter((n) => n !== name) : [...prev, name]
    );
  };

  const goToExercise = (index: number) => {
    if (index >= 0 && index < dayExercises.length) {
      setCurrentExerciseIndex(index);
      scrollRef.current?.scrollTo({ y: 0, animated: true });
    }
  };

  const handleFinish = async () => {
    if (!user) return;
    const duration = Math.max(Math.round(elapsedSeconds / 60), 1);
    await supabase.from('workout_history').insert({
      user_id: user.id,
      workout_name: day.title,
      exercises: day.exercises,
      duration_minutes: duration,
      calories_burned: totalCalories,
      difficulty: day.difficulty,
    });
    router.replace('/(tabs)/progress');
  };

  const progressPercent = isRestDay ? 0 : (completedExercises.length / dayExercises.length) * 100;

  return (
    <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
      {/* Header with back button */}
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backBtn}
          activeOpacity={0.7}
        >
          <ChevronLeft color={COLORS.neonGreen} size={24} strokeWidth={2.5} />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <Text style={styles.headerDay}>{day.day}</Text>
          <Text style={styles.headerTitle} numberOfLines={1}>{day.title}</Text>
        </View>
        <View style={styles.headerDayBadge}>
          <Text style={styles.headerDayBadgeText}>{day.shortDay}</Text>
        </View>
      </View>

      {/* Progress + Timer bar */}
      {!isRestDay && (
        <View style={styles.progressContainer}>
          <View style={styles.progressInfo}>
            <Text style={styles.progressText}>
              {completedExercises.length}/{dayExercises.length} completed
            </Text>
            <View style={styles.timerRow}>
              <Timer color={COLORS.neonGreen} size={16} strokeWidth={2.5} />
              <Text style={styles.timerText}>{formatTime(elapsedSeconds)}</Text>
              <TouchableOpacity
                onPress={() => setTimerRunning(!timerRunning)}
                style={styles.timerBtn}
                activeOpacity={0.7}
              >
                {timerRunning ? (
                  <Pause color={COLORS.neonGreen} size={16} strokeWidth={2.5} />
                ) : (
                  <Play color={COLORS.neonGreen} size={16} strokeWidth={2.5} />
                )}
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => { setTimerRunning(false); setElapsedSeconds(0); }}
                style={styles.timerBtn}
                activeOpacity={0.7}
              >
                <RotateCcw color={COLORS.gray} size={16} strokeWidth={2} />
              </TouchableOpacity>
            </View>
          </View>
          <View style={styles.progressBar}>
            <LinearGradient
              colors={[COLORS.neonGreen, COLORS.neonGreenDim]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={[styles.progressFill, { width: `${progressPercent}%` }]}
            />
          </View>
        </View>
      )}

      {/* Full-screen scrollable content */}
      <ScrollView
        ref={scrollRef}
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Focus banner */}
        {!isRestDay && (
          <View style={styles.focusBanner}>
            <Calendar color={COLORS.neonGreen} size={14} strokeWidth={2.5} />
            <Text style={styles.focusText}>{day.focus}</Text>
            <Badge text={day.difficulty} />
          </View>
        )}

        {isRestDay ? (
          <View style={styles.restDayContainer}>
            <View style={styles.restDayIconWrap}>
              <Heart color={COLORS.neonGreen} size={48} strokeWidth={1.5} />
            </View>
            <Text style={styles.restDayTitle}>Rest & Recovery Day</Text>
            <Text style={styles.restDayDesc}>
              Take time to recover. Do light stretching, walk, or practice mobility work. Rest is when your muscles grow and repair.
            </Text>
            <View style={styles.restTipsContainer}>
              <Text style={styles.restDayTip}>Tips for recovery:</Text>
              <Text style={styles.restDayTipItem}>Stay hydrated - drink plenty of water</Text>
              <Text style={styles.restDayTipItem}>Get 7-9 hours of quality sleep</Text>
              <Text style={styles.restDayTipItem}>Light stretching or foam rolling</Text>
              <Text style={styles.restDayTipItem}>Eat protein-rich meals for muscle repair</Text>
            </View>
          </View>
        ) : currentExercise ? (
          <View key={currentExercise.id}>
            {/* Exercise counter pill */}
            <View style={styles.exerciseCounterRow}>
              <Text style={styles.exerciseCounterText}>
                Exercise {currentExerciseIndex + 1} of {dayExercises.length}
              </Text>
              {isCurrentCompleted && (
                <View style={styles.completedPill}>
                  <CheckCircle2 color={COLORS.neonGreen} size={12} strokeWidth={2.5} />
                  <Text style={styles.completedPillText}>Done</Text>
                </View>
              )}
            </View>

            {/* Exercise card with large demo image */}
            <View style={styles.exerciseCard}>
              <View style={styles.exerciseImageContainer}>
                <Image
                  source={{ uri: getExerciseImage(currentExercise.name) }}
                  style={styles.exerciseImage}
                  resizeMode="cover"
                />
                <LinearGradient
                  colors={['transparent', 'rgba(0,0,0,0.8)']}
                  style={styles.exerciseImageOverlay}
                />
                <View style={styles.exerciseNumberBadge}>
                  <Text style={styles.exerciseNumberText}>{currentExerciseIndex + 1}</Text>
                </View>
                <View style={styles.exerciseNameOverlay}>
                  <Text style={styles.exerciseName}>{currentExercise.name}</Text>
                  <Text style={styles.exerciseMuscle}>
                    {currentExercise.muscle_group} · {currentExercise.equipment}
                  </Text>
                </View>
              </View>

              {/* Exercise info */}
              <View style={styles.exerciseInfo}>
                {/* Stat badges */}
                <View style={styles.exerciseBadgeRow}>
                  <View style={styles.exerciseStatBadge}>
                    <Dumbbell color={COLORS.accentBlue} size={13} strokeWidth={2.5} />
                    <Text style={styles.exerciseStatBadgeText}>{currentExercise.sets_reps}</Text>
                  </View>
                  <View style={styles.exerciseStatBadge}>
                    <Timer color={COLORS.warning} size={13} strokeWidth={2.5} />
                    <Text style={styles.exerciseStatBadgeText}>{currentExercise.rest_seconds}s rest</Text>
                  </View>
                  <View style={styles.exerciseStatBadge}>
                    <Flame color={COLORS.neonGreen} size={13} strokeWidth={2.5} />
                    <Text style={styles.exerciseStatBadgeText}>~{currentExercise.calories_per_set * 3} cal</Text>
                  </View>
                </View>

                {/* How to perform */}
                <View style={styles.sectionHeader}>
                  <Info color={COLORS.neonGreen} size={15} strokeWidth={2.5} />
                  <Text style={styles.sectionTitle}>How to Perform</Text>
                </View>
                {currentExercise.instructions.map((step, i) => (
                  <View key={i} style={styles.stepRow}>
                    <View style={styles.stepNumber}>
                      <Text style={styles.stepNumberText}>{i + 1}</Text>
                    </View>
                    <Text style={styles.stepText}>{step}</Text>
                  </View>
                ))}

                {/* Form tips - beginner friendly */}
                <View style={styles.sectionHeader}>
                  <Target color={COLORS.neonGreen} size={15} strokeWidth={2.5} />
                  <Text style={styles.sectionTitle}>Proper Form Guide</Text>
                </View>
                <View style={styles.formGuideBox}>
                  <Text style={styles.formGuideText}>
                    {generateFormTip(currentExercise.name, currentExercise.muscle_group)}
                  </Text>
                </View>

                {/* Safety tips */}
                <View style={styles.sectionHeader}>
                  <ShieldCheck color={COLORS.neonGreen} size={15} strokeWidth={2.5} />
                  <Text style={styles.sectionTitle}>Safety Tips</Text>
                </View>
                {currentExercise.safety_tips.map((tip, i) => (
                  <View key={i} style={styles.tipRow}>
                    <View style={styles.tipDot} />
                    <Text style={styles.tipText}>{tip}</Text>
                  </View>
                ))}

                {/* Mark as completed */}
                <TouchableOpacity
                  onPress={() => toggleExercise(currentExercise.name)}
                  style={[styles.completeBtn, isCurrentCompleted && styles.completeBtnDone]}
                  activeOpacity={0.8}
                >
                  <CheckCircle2
                    color={isCurrentCompleted ? COLORS.neonGreen : COLORS.gray}
                    size={18}
                    strokeWidth={2.5}
                  />
                  <Text style={[styles.completeText, isCurrentCompleted && styles.completeTextDone]}>
                    {isCurrentCompleted ? 'Completed' : 'Mark as Complete'}
                  </Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* Previous / Next navigation */}
            <View style={styles.navRow}>
              <TouchableOpacity
                onPress={() => goToExercise(currentExerciseIndex - 1)}
                disabled={isFirstExercise}
                style={[styles.navBtn, isFirstExercise && styles.navBtnDisabled]}
                activeOpacity={0.7}
              >
                <ChevronLeft color={isFirstExercise ? COLORS.grayDark : COLORS.neonGreen} size={18} strokeWidth={2.5} />
                <Text style={[styles.navBtnText, isFirstExercise && styles.navBtnTextDisabled]}>Previous</Text>
              </TouchableOpacity>

              {isLastExercise ? (
                <TouchableOpacity
                  onPress={handleFinish}
                  style={styles.navBtnFinish}
                  activeOpacity={0.8}
                >
                  <Text style={styles.navBtnFinishText}>Finish</Text>
                  <CheckCircle2 color={COLORS.black} size={16} strokeWidth={2.5} />
                </TouchableOpacity>
              ) : (
                <TouchableOpacity
                  onPress={() => goToExercise(currentExerciseIndex + 1)}
                  style={styles.navBtnNext}
                  activeOpacity={0.7}
                >
                  <Text style={styles.navBtnNextText}>Next</Text>
                  <ArrowRight color={COLORS.black} size={16} strokeWidth={2.5} />
                </TouchableOpacity>
              )}
            </View>

            {/* Exercise dots indicator */}
            <View style={styles.dotsContainer}>
              {dayExercises.map((_, i) => (
                <View
                  key={i}
                  style={[
                    styles.dot,
                    i === currentExerciseIndex && styles.dotActive,
                    completedExercises.includes(dayExercises[i].name) && styles.dotCompleted,
                  ]}
                />
              ))}
            </View>
          </View>
        ) : (
          <View style={styles.loadingContainer}>
            <Text style={styles.loadingText}>Loading exercises...</Text>
          </View>
        )}

        {/* Finish & Save button - shown when at least one exercise is completed */}
        {!isRestDay && completedExercises.length > 0 && !isLastExercise && (
          <TouchableOpacity
            onPress={handleFinish}
            style={styles.finishBtn}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={[COLORS.neonGreen, COLORS.neonGreenDim]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.finishBtnGradient}
            >
              <CheckCircle2 color={COLORS.black} size={18} strokeWidth={2.5} />
              <Text style={styles.finishBtnText}>Finish & Save Workout</Text>
            </LinearGradient>
          </TouchableOpacity>
        )}

        <View style={{ height: SPACING.xxl }} />
      </ScrollView>
    </SafeAreaView>
  );
}

function generateFormTip(name: string, muscle: string): string {
  const tips: Record<string, string> = {
    'Push-Ups': 'Keep your body in a straight line from head to heels. Lower your chest toward the floor by bending your elbows at a 45-degree angle. Don\'t let your hips sag or pike up. Push through your palms to return to start.',
    'Bodyweight Squats': 'Stand with feet shoulder-width apart. Push your hips back and bend your knees as if sitting in a chair. Keep your chest tall and weight in your heels. Go down until thighs are parallel to the floor, then drive up through your heels.',
    'Dumbbell Bicep Curls': 'Keep your elbows pinned to your sides throughout the movement. Curl the weight up slowly, squeezing your bicep at the top. Lower slowly with control - do not swing your body or use momentum.',
    'Plank': 'Rest on your forearms with elbows under your shoulders. Squeeze your glutes and brace your core. Keep your body in a perfectly straight line - no sagging hips or raised bum. Breathe steadily and hold.',
    'Lunges': 'Step forward and lower your back knee toward the floor. Keep your front knee directly over your ankle - do not let it cave inward. Keep your torso upright and push through the front heel to return.',
    'Mountain Climbers': 'Start in a high plank with hands under shoulders. Drive one knee toward your chest, then switch legs quickly. Keep your hips down and core tight. Move at a controlled but brisk pace.',
    'Dumbbell Shoulder Press': 'Sit or stand with your back straight. Press the dumbbells overhead until your arms are fully extended. Lower slowly to shoulder level. Avoid arching your back - keep your core engaged.',
    'Bench Press': 'Lie flat with feet on the floor. Grip the bar slightly wider than shoulder-width. Lower the bar to your mid-chest with control, then press up powerfully. Keep your shoulder blades squeezed together.',
    'Deadlift': 'Stand with the bar over your mid-foot. Bend at hips and knees to grip the bar. Keep your back flat and chest up. Drive through your legs and hips to stand tall. Lower with control by hinging at the hips.',
    'Pull-Ups': 'Grip the bar with palms facing away, slightly wider than shoulders. Pull your chin above the bar by driving your elbows down. Lower with control - avoid swinging. Engage your lats and core.',
    'Overhead Press': 'Start with the bar at shoulder height. Press straight overhead until arms lock out. Keep your core tight and avoid leaning back. Lower with control to the starting position.',
    'Romanian Deadlift': 'Hold the bar with a shoulder-width grip. Hinge at your hips, pushing your glutes back. Keep your back flat and a slight bend in your knees. Lower the bar to mid-shin, then squeeze glutes to stand.',
    'Bent-Over Rows': 'Hinge forward at the hips with a flat back. Pull the bar or dumbbells to your lower ribs, squeezing your shoulder blades together. Lower with control. Keep your core tight to protect your lower back.',
    'Barbell Back Squat': 'Rest the bar on your upper traps. Stand with feet shoulder-width. Brace your core, sit back and down. Keep your knees tracking over your toes. Go below parallel if flexible, then drive up through your heels.',
    'Weighted Dips': 'Grip the parallel bars and support your body. Lower yourself by bending your elbows, keeping them close to your body. Lean slightly forward for chest emphasis. Push down to return to start.',
    'Muscle-Ups': 'Start with a false grip on the bar. Pull up explosively, then transition your elbows above the bar. Press up to full extension. Lower with control. This is an advanced move - practice pull-ups and dips first.',
    'Pistol Squats': 'Stand on one leg with the other extended in front. Lower your hips toward the floor on one leg, keeping the extended leg straight. Go as low as you can, then push back up. Use a support if needed.',
    'Hanging Leg Raises': 'Hang from a bar with arms extended. Keeping your legs straight, raise them to hip height or higher. Lower slowly without swinging. Engage your core throughout - avoid using momentum.',
  };
  return tips[name] || `Focus on controlled, steady movements for ${muscle}. Keep your core engaged, maintain good posture, and breathe out during the effort phase. Start with lighter weight to master the form before progressing.`;
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.black,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.sm,
    paddingVertical: SPACING.sm,
    backgroundColor: COLORS.darkGray,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  backBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: COLORS.cardBg,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: COLORS.neonGreen + '30',
  },
  headerCenter: {
    flex: 1,
    alignItems: 'center',
    marginHorizontal: SPACING.xs,
  },
  headerDay: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.gray,
    letterSpacing: 1.5,
    textTransform: 'uppercase',
  },
  headerTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.md,
    color: COLORS.white,
    marginTop: 1,
  },
  headerDayBadge: {
    width: 38,
    height: 38,
    borderRadius: 12,
    backgroundColor: COLORS.neonGreen,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerDayBadgeText: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.xs,
    color: COLORS.black,
  },
  // Progress + timer
  progressContainer: {
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm + 2,
    backgroundColor: COLORS.darkGray,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  progressInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.sm,
  },
  progressText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.sm,
    color: COLORS.white,
  },
  timerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
  },
  timerText: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.md,
    color: COLORS.neonGreen,
  },
  timerBtn: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: COLORS.cardBg,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  progressBar: {
    height: 4,
    backgroundColor: COLORS.cardBgLight,
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 2,
  },
  // Scroll
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: SPACING.md,
    paddingTop: SPACING.md,
    paddingBottom: TAB_BAR_HEIGHT + SPACING.lg,
  },
  // Focus banner
  focusBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    marginBottom: SPACING.md,
    backgroundColor: COLORS.cardBg,
    borderRadius: BORDER_RADIUS.md,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
  },
  focusText: {
    flex: 1,
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.sm,
    color: COLORS.grayLight,
  },
  // Exercise counter
  exerciseCounterRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.sm,
    paddingHorizontal: SPACING.xs,
  },
  exerciseCounterText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.sm,
    color: COLORS.grayLight,
  },
  completedPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: COLORS.neonGreen + '18',
    paddingHorizontal: SPACING.sm,
    paddingVertical: 3,
    borderRadius: BORDER_RADIUS.pill,
  },
  completedPillText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.xs,
    color: COLORS.neonGreen,
  },
  // Exercise card
  exerciseCard: {
    backgroundColor: COLORS.cardBg,
    borderRadius: BORDER_RADIUS.lg,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  exerciseImageContainer: {
    width: '100%',
    height: imageHeight,
    position: 'relative',
  },
  exerciseImage: {
    width: '100%',
    height: '100%',
  },
  exerciseImageOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '60%',
  },
  exerciseNumberBadge: {
    position: 'absolute',
    top: SPACING.sm,
    left: SPACING.sm,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: COLORS.neonGreen,
    alignItems: 'center',
    justifyContent: 'center',
  },
  exerciseNumberText: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.sm,
    color: COLORS.black,
  },
  exerciseNameOverlay: {
    position: 'absolute',
    bottom: SPACING.sm,
    left: SPACING.md,
    right: SPACING.md,
  },
  exerciseName: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.xl,
    color: COLORS.white,
  },
  exerciseMuscle: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.grayLight,
    marginTop: 2,
    textTransform: 'capitalize',
  },
  // Exercise info
  exerciseInfo: {
    padding: SPACING.md,
  },
  exerciseBadgeRow: {
    flexDirection: 'row',
    gap: SPACING.sm,
    marginBottom: SPACING.md,
    flexWrap: 'wrap',
  },
  exerciseStatBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.xs,
    backgroundColor: COLORS.cardBgLight,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.xs + 1,
    borderRadius: BORDER_RADIUS.pill,
  },
  exerciseStatBadgeText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.xs,
    color: COLORS.white,
  },
  // Section headers
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    marginBottom: SPACING.sm,
    marginTop: SPACING.md,
  },
  sectionTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.md,
    color: COLORS.white,
  },
  // Steps
  stepRow: {
    flexDirection: 'row',
    gap: SPACING.sm,
    marginBottom: SPACING.sm,
  },
  stepNumber: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: COLORS.neonGreen,
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
  stepNumberText: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.xs,
    color: COLORS.black,
  },
  stepText: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.sm,
    color: COLORS.offWhite,
    lineHeight: 21,
    flex: 1,
  },
  // Form guide
  formGuideBox: {
    backgroundColor: COLORS.neonGreen + '0D',
    borderRadius: BORDER_RADIUS.md,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm + 2,
    borderLeftWidth: 3,
    borderLeftColor: COLORS.neonGreen,
  },
  formGuideText: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.sm,
    color: COLORS.offWhite,
    lineHeight: 21,
  },
  // Tips
  tipRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: SPACING.sm,
    marginBottom: SPACING.sm,
  },
  tipDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: COLORS.neonGreen,
    marginTop: 6,
    flexShrink: 0,
  },
  tipText: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.sm,
    color: COLORS.grayLight,
    lineHeight: 20,
    flex: 1,
  },
  // Complete button
  completeBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: SPACING.sm,
    paddingVertical: SPACING.md,
    borderRadius: BORDER_RADIUS.md,
    backgroundColor: COLORS.cardBgLight,
    borderWidth: 1,
    borderColor: COLORS.border,
    marginTop: SPACING.md,
  },
  completeBtnDone: {
    backgroundColor: COLORS.neonGreen + '15',
    borderColor: COLORS.neonGreen + '50',
  },
  completeText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.sm,
    color: COLORS.gray,
  },
  completeTextDone: {
    color: COLORS.neonGreen,
  },
  // Navigation
  navRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: SPACING.md,
    gap: SPACING.sm,
  },
  navBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: SPACING.xs,
    paddingVertical: SPACING.md,
    borderRadius: BORDER_RADIUS.md,
    backgroundColor: COLORS.cardBg,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  navBtnDisabled: {
    opacity: 0.4,
  },
  navBtnText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.sm,
    color: COLORS.neonGreen,
  },
  navBtnTextDisabled: {
    color: COLORS.grayDark,
  },
  navBtnNext: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: SPACING.xs,
    paddingVertical: SPACING.md,
    borderRadius: BORDER_RADIUS.md,
    backgroundColor: COLORS.neonGreen,
  },
  navBtnNextText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.sm,
    color: COLORS.black,
  },
  navBtnFinish: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: SPACING.xs,
    paddingVertical: SPACING.md,
    borderRadius: BORDER_RADIUS.md,
    backgroundColor: COLORS.neonGreen,
  },
  navBtnFinishText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.sm,
    color: COLORS.black,
  },
  // Dots indicator
  dotsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 6,
    marginTop: SPACING.md,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: COLORS.cardBgLight,
  },
  dotActive: {
    width: 24,
    borderRadius: 4,
    backgroundColor: COLORS.neonGreen,
  },
  dotCompleted: {
    backgroundColor: COLORS.neonGreenDim,
  },
  // Finish button
  finishBtn: {
    marginTop: SPACING.lg,
    borderRadius: BORDER_RADIUS.md,
    overflow: 'hidden',
  },
  finishBtnGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: SPACING.sm,
    paddingVertical: SPACING.md + 2,
  },
  finishBtnText: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.md,
    color: COLORS.black,
  },
  // Rest day
  restDayContainer: {
    alignItems: 'center',
    paddingVertical: SPACING.xxl,
    gap: SPACING.sm,
  },
  restDayIconWrap: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: COLORS.neonGreen + '12',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: SPACING.sm,
  },
  restDayTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.xl,
    color: COLORS.white,
  },
  restDayDesc: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.sm,
    color: COLORS.grayLight,
    textAlign: 'center',
    lineHeight: 21,
    paddingHorizontal: SPACING.lg,
  },
  restTipsContainer: {
    alignItems: 'flex-start',
    marginTop: SPACING.lg,
    paddingHorizontal: SPACING.xl,
    width: '100%',
  },
  restDayTip: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.md,
    color: COLORS.neonGreen,
    marginBottom: SPACING.sm,
  },
  restDayTipItem: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.sm,
    color: COLORS.grayLight,
    marginTop: SPACING.xs,
    lineHeight: 20,
  },
  // Loading
  loadingContainer: {
    alignItems: 'center',
    paddingVertical: SPACING.xxl,
  },
  loadingText: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.md,
    color: COLORS.gray,
  },
});

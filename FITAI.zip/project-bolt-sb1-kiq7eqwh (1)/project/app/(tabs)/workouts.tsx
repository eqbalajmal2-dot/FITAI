import { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Modal,
  RefreshControl,
  Image,
  Dimensions,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect, useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import {
  Dumbbell,
  Clock,
  Flame,
  ChevronRight,
  X,
  Activity,
  Utensils,
  Apple,
  Drumstick,
  Cookie,
  Info,
  ShieldCheck,
  Calendar,
  Play,
  Heart,
} from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { Card, Badge, NeonButton, SectionHeader } from '@/components/ui';
import { COLORS, SPACING, FONT_SIZES, BORDER_RADIUS } from '@/constants/theme';
import { Exercise, WorkoutPlan } from '@/types/database';
import { MEAL_SUGGESTIONS } from '@/constants/meals';
import { getExerciseImage, WEEKLY_PLAN, WeeklyDay } from '@/constants/exerciseImages';

const screenWidth = Dimensions.get('window').width;
const cardWidth = screenWidth - SPACING.lg * 2;

type TabKey = 'weekly' | 'plans' | 'exercises' | 'nutrition';

export default function WorkoutsScreen() {
  const { user } = useAuth();
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<TabKey>('weekly');
  const [plans, setPlans] = useState<WorkoutPlan[]>([]);
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null);

  const loadData = async () => {
    const [plansRes, exercisesRes] = await Promise.all([
      supabase.from('workout_plans').select('*').order('difficulty'),
      supabase.from('exercises').select('*').order('difficulty'),
    ]);
    if (plansRes.data) setPlans(plansRes.data as WorkoutPlan[]);
    if (exercisesRes.data) setExercises(exercisesRes.data as Exercise[]);
  };

  useFocusEffect(useCallback(() => {
    loadData();
  }, []));

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const tabs: { key: TabKey; label: string }[] = [
    { key: 'weekly', label: 'Weekly Plan' },
    { key: 'plans', label: 'Workout Plans' },
    { key: 'exercises', label: 'Exercises' },
    { key: 'nutrition', label: 'Nutrition' },
  ];

  const getExerciseByName = (name: string) => exercises.find((e) => e.name === name);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Workouts</Text>
        <Text style={styles.headerSubtitle}>Train smart, train hard</Text>
      </View>

      {/* Tab Switcher */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabBarScroll} contentContainerStyle={styles.tabBarContent}>
        {tabs.map((tab) => (
          <TouchableOpacity
            key={tab.key}
            onPress={() => setActiveTab(tab.key)}
            style={[styles.tabItem, activeTab === tab.key && styles.tabItemActive]}
            activeOpacity={0.7}
          >
            <Text style={[styles.tabText, activeTab === tab.key && styles.tabTextActive]}>
              {tab.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={COLORS.neonGreen} />}
      >
        {activeTab === 'weekly' && (
          <WeeklyPlanView
            exercises={exercises}
            getExerciseByName={getExerciseByName}
            onSelectDay={(day) => {
              const idx = WEEKLY_PLAN.findIndex((d) => d.day === day.day);
              router.push({ pathname: '/(tabs)/workout-day', params: { dayIndex: String(idx) } });
            }}
          />
        )}

        {activeTab === 'plans' && (
          <View>
            {plans.map((plan) => (
              <PlanCard key={plan.id} plan={plan} onSelect={() => setSelectedExercise(null)} />
            ))}
          </View>
        )}

        {activeTab === 'exercises' && (
          <View>
            {exercises.map((exercise) => (
              <ExerciseCard key={exercise.id} exercise={exercise} onPress={() => setSelectedExercise(exercise)} />
            ))}
          </View>
        )}

        {activeTab === 'nutrition' && <NutritionView />}

        <View style={{ height: 90 }} />
      </ScrollView>

      {/* Exercise Detail Modal with demonstration image */}
      <ExerciseDetailModal
        exercise={selectedExercise}
        onClose={() => setSelectedExercise(null)}
      />
    </SafeAreaView>
  );
}

// ============================================================================
// WEEKLY PLAN VIEW
// ============================================================================
function WeeklyPlanView({
  exercises,
  getExerciseByName,
  onSelectDay,
}: {
  exercises: Exercise[];
  getExerciseByName: (name: string) => Exercise | undefined;
  onSelectDay: (day: WeeklyDay) => void;
}) {
  const today = new Date().toLocaleDateString('en-US', { weekday: 'long' });

  return (
    <View>
      <Card style={styles.weeklyHeaderCard}>
        <View style={styles.weeklyHeaderRow}>
          <Calendar color={COLORS.neonGreen} size={22} strokeWidth={2.5} />
          <View style={{ flex: 1 }}>
            <Text style={styles.weeklyHeaderTitle}>Weekly Schedule</Text>
            <Text style={styles.weeklyHeaderSub}>Monday to Sunday workout plan</Text>
          </View>
        </View>
      </Card>

      {WEEKLY_PLAN.map((day) => {
        const isToday = day.day === today;
        const dayExercises = day.exercises.map(getExerciseByName).filter((e): e is Exercise => !!e);
        const totalCalories = dayExercises.reduce((sum, e) => sum + e.calories_per_set * 3, 0);
        const isRestDay = day.exercises.length === 0;

        return (
          <TouchableOpacity
            key={day.day}
            onPress={() => onSelectDay(day)}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={isToday ? ['#0A2218', COLORS.cardBg] : [COLORS.cardBg, COLORS.cardBg]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={[styles.dayCard, isToday && styles.dayCardToday]}
            >
              <View style={styles.dayCardLeft}>
                <View style={[styles.dayBadge, isToday && styles.dayBadgeToday]}>
                  <Text style={[styles.dayBadgeText, isToday && styles.dayBadgeTextToday]}>{day.shortDay}</Text>
                </View>
                <View style={styles.dayInfo}>
                  <View style={styles.dayTitleRow}>
                    <Text style={styles.dayTitle}>{day.title}</Text>
                    {isToday && <Badge text="Today" />}
                  </View>
                  <Text style={styles.dayFocus}>{day.focus}</Text>
                  <View style={styles.dayMetaRow}>
                    {!isRestDay ? (
                      <>
                        <View style={styles.dayMetaItem}>
                          <Dumbbell color={COLORS.gray} size={12} strokeWidth={2} />
                          <Text style={styles.dayMetaText}>{dayExercises.length} exercises</Text>
                        </View>
                        <View style={styles.dayMetaItem}>
                          <Flame color={COLORS.gray} size={12} strokeWidth={2} />
                          <Text style={styles.dayMetaText}>~{totalCalories} cal</Text>
                        </View>
                        <Badge text={day.difficulty} />
                      </>
                    ) : (
                      <View style={styles.dayMetaItem}>
                        <Heart color={COLORS.neonGreen} size={12} strokeWidth={2} />
                        <Text style={styles.dayMetaText}>Recovery & rest day</Text>
                      </View>
                    )}
                  </View>
                </View>
              </View>
              <ChevronRight color={isToday ? COLORS.neonGreen : COLORS.gray} size={22} strokeWidth={2.5} />
            </LinearGradient>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

// ============================================================================
// PLAN CARD
// ============================================================================
function PlanCard({ plan, onSelect }: { plan: WorkoutPlan; onSelect: () => void }) {
  return (
    <Card style={styles.planCard} onPress={onSelect}>
      <LinearGradient
        colors={['#0A2218', COLORS.cardBg]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.planGradient}
      >
        <View style={styles.planTop}>
          <View style={styles.planIconBox}>
            <Dumbbell color={COLORS.neonGreen} size={24} strokeWidth={2.5} />
          </View>
          <View style={styles.planMeta}>
            <Badge text={plan.difficulty} />
            <Badge text={plan.category} color={COLORS.accentBlue} />
          </View>
        </View>
        <Text style={styles.planName}>{plan.name}</Text>
        <Text style={styles.planDesc}>{plan.description}</Text>
        <View style={styles.planStatsRow}>
          <View style={styles.planStatItem}>
            <Clock color={COLORS.gray} size={14} strokeWidth={2} />
            <Text style={styles.planStatText}>{plan.duration_minutes} min</Text>
          </View>
          <View style={styles.planStatItem}>
            <Flame color={COLORS.gray} size={14} strokeWidth={2} />
            <Text style={styles.planStatText}>{plan.calories_estimate} cal</Text>
          </View>
          <View style={styles.planStatItem}>
            <Dumbbell color={COLORS.gray} size={14} strokeWidth={2} />
            <Text style={styles.planStatText}>{plan.exercise_ids.length} exercises</Text>
          </View>
        </View>
      </LinearGradient>
    </Card>
  );
}

// ============================================================================
// EXERCISE CARD
// ============================================================================
function ExerciseCard({ exercise, onPress }: { exercise: Exercise; onPress: () => void }) {
  return (
    <Card key={exercise.id} style={styles.exerciseCard} onPress={onPress}>
      <View style={styles.exerciseImageContainer}>
        <Image source={{ uri: getExerciseImage(exercise.name) }} style={styles.exerciseImage} resizeMode="cover" />
        <LinearGradient
          colors={['transparent', 'rgba(0,0,0,0.7)']}
          style={styles.exerciseImageOverlay}
        />
        <View style={styles.exerciseImageBadgeRow}>
          <Badge text={exercise.difficulty} />
        </View>
        <View style={styles.exerciseImageNameOverlay}>
          <Text style={styles.exerciseImageName}>{exercise.name}</Text>
          <Text style={styles.exerciseImageMeta}>{exercise.muscle_group} · {exercise.equipment}</Text>
        </View>
      </View>
      <View style={styles.exerciseStatsRow}>
        <View style={styles.exerciseStat}>
          <Text style={styles.exerciseStatLabel}>Sets/Reps</Text>
          <Text style={styles.exerciseStatValue}>{exercise.sets_reps}</Text>
        </View>
        <View style={styles.exerciseStat}>
          <Text style={styles.exerciseStatLabel}>Rest</Text>
          <Text style={styles.exerciseStatValue}>{exercise.rest_seconds}s</Text>
        </View>
        <View style={styles.exerciseStat}>
          <Text style={styles.exerciseStatLabel}>Cal/Set</Text>
          <Text style={styles.exerciseStatValue}>{exercise.calories_per_set}</Text>
        </View>
        <View style={styles.exerciseViewBtn}>
          <Play color={COLORS.neonGreen} size={14} strokeWidth={2.5} />
          <Text style={styles.exerciseViewText}>View</Text>
        </View>
      </View>
    </Card>
  );
}

// ============================================================================
// NUTRITION VIEW
// ============================================================================
function NutritionView() {
  return (
    <View>
      <Card style={styles.nutritionHeaderCard}>
        <Utensils color={COLORS.neonGreen} size={24} strokeWidth={2.5} />
        <Text style={styles.nutritionHeaderTitle}>Personalized Meal Suggestions</Text>
        <Text style={styles.nutritionHeaderDesc}>
          Fuel your body with balanced meals tailored for fitness goals
        </Text>
      </Card>
      {(['breakfast', 'lunch', 'dinner', 'snack'] as const).map((mealType) => {
        const meals = MEAL_SUGGESTIONS.filter((m) => m.type === mealType);
        if (meals.length === 0) return null;
        const icon = mealType === 'breakfast' ? <Apple size={18} color={COLORS.neonGreen} strokeWidth={2.5} /> :
          mealType === 'lunch' || mealType === 'dinner' ? <Drumstick size={18} color={COLORS.neonGreen} strokeWidth={2.5} /> :
          <Cookie size={18} color={COLORS.neonGreen} strokeWidth={2.5} />;
        return (
          <View key={mealType} style={styles.mealSection}>
            <View style={styles.mealTypeHeader}>
              {icon}
              <Text style={styles.mealTypeTitle}>{mealType.charAt(0).toUpperCase() + mealType.slice(1)}</Text>
            </View>
            {meals.map((meal) => (
              <Card key={meal.id} style={styles.mealCard}>
                <Text style={styles.mealName}>{meal.name}</Text>
                <Text style={styles.mealDesc}>{meal.description}</Text>
                <View style={styles.mealStatsRow}>
                  <View style={styles.mealStatBox}>
                    <Text style={styles.mealStatValue}>{meal.calories}</Text>
                    <Text style={styles.mealStatLabel}>cal</Text>
                  </View>
                  <View style={styles.mealStatBox}>
                    <Text style={styles.mealStatValue}>{meal.protein_g}g</Text>
                    <Text style={styles.mealStatLabel}>protein</Text>
                  </View>
                  <View style={styles.mealStatBox}>
                    <Text style={styles.mealStatValue}>{meal.carbs_g}g</Text>
                    <Text style={styles.mealStatLabel}>carbs</Text>
                  </View>
                  <View style={styles.mealStatBox}>
                    <Text style={styles.mealStatValue}>{meal.fats_g}g</Text>
                    <Text style={styles.mealStatLabel}>fats</Text>
                  </View>
                </View>
                <View style={styles.ingredientsContainer}>
                  <Text style={styles.ingredientsTitle}>Ingredients:</Text>
                  {meal.ingredients.map((ing, i) => (
                    <Text key={i} style={styles.ingredientItem}>· {ing}</Text>
                  ))}
                </View>
              </Card>
            ))}
          </View>
        );
      })}
    </View>
  );
}

// ============================================================================
// EXERCISE DETAIL MODAL - with human demonstration
// ============================================================================
function ExerciseDetailModal({
  exercise,
  onClose,
}: {
  exercise: Exercise | null;
  onClose: () => void;
}) {
  if (!exercise) return null;

  return (
    <Modal
      visible={!!exercise}
      animationType="slide"
      transparent={true}
      onRequestClose={onClose}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.exerciseModalContent}>
          <View style={styles.exerciseModalHeader}>
            <View style={styles.exerciseModalHeaderLeft}>
              <View style={styles.modalIconBox}>
                <Dumbbell color={COLORS.neonGreen} size={22} strokeWidth={2.5} />
              </View>
              <View>
                <Text style={styles.modalTitle}>{exercise.name}</Text>
                <Text style={styles.modalSubtitle}>{exercise.muscle_group} · {exercise.equipment}</Text>
              </View>
            </View>
            <TouchableOpacity onPress={onClose} style={styles.closeBtn}>
              <X color={COLORS.gray} size={22} strokeWidth={2} />
            </TouchableOpacity>
          </View>

          <ScrollView showsVerticalScrollIndicator={false} style={styles.modalScroll}>
            {/* Human demonstration image */}
            <View style={styles.demonstrationContainer}>
              <Image
                source={{ uri: getExerciseImage(exercise.name) }}
                style={styles.demonstrationImage}
                resizeMode="cover"
              />
              <LinearGradient
                colors={['transparent', 'rgba(0,0,0,0.8)']}
                style={styles.demonstrationOverlay}
              />
              <View style={styles.demonstrationBadge}>
                <Activity color={COLORS.neonGreen} size={12} strokeWidth={2.5} />
                <Text style={styles.demonstrationBadgeText}>Demonstration</Text>
              </View>
              <View style={styles.demonstrationInfoOverlay}>
                <View style={styles.demonstrationBadgeRow}>
                  <Badge text={exercise.difficulty} />
                  <Badge text={exercise.sets_reps} color={COLORS.accentBlue} />
                  <Badge text={`Rest: ${exercise.rest_seconds}s`} color={COLORS.warning} />
                </View>
                <Text style={styles.demonstrationFormText}>
                  Study the form shown above. Maintain proper posture throughout the movement.
                </Text>
              </View>
            </View>

            {/* Step-by-step instructions */}
            <View style={styles.modalSection}>
              <View style={styles.modalSectionHeader}>
                <Info color={COLORS.neonGreen} size={18} strokeWidth={2.5} />
                <Text style={styles.modalSectionTitle}>Step-by-Step Instructions</Text>
              </View>
              {exercise.instructions.map((step, i) => (
                <View key={i} style={styles.stepRow}>
                  <View style={styles.stepNumber}>
                    <Text style={styles.stepNumberText}>{i + 1}</Text>
                  </View>
                  <Text style={styles.stepText}>{step}</Text>
                </View>
              ))}
            </View>

            {/* Safety tips */}
            <View style={styles.modalSection}>
              <View style={styles.modalSectionHeader}>
                <ShieldCheck color={COLORS.neonGreen} size={18} strokeWidth={2.5} />
                <Text style={styles.modalSectionTitle}>Safety Tips</Text>
              </View>
              {exercise.safety_tips.map((tip, i) => (
                <View key={i} style={styles.tipRow}>
                  <View style={styles.tipDot} />
                  <Text style={styles.tipText}>{tip}</Text>
                </View>
              ))}
            </View>

            <View style={{ height: SPACING.xxl }} />
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

// ============================================================================
// STYLES
// ============================================================================
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.black,
  },
  header: {
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.md,
  },
  headerTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.xxxl,
    color: COLORS.white,
  },
  headerSubtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.sm,
    color: COLORS.gray,
    marginTop: 2,
  },
  tabBarScroll: {
    maxHeight: 44,
  },
  tabBarContent: {
    paddingHorizontal: SPACING.lg,
    gap: SPACING.sm,
    paddingBottom: SPACING.xs,
  },
  tabItem: {
    paddingVertical: SPACING.sm + 2,
    paddingHorizontal: SPACING.md,
    alignItems: 'center',
    borderRadius: BORDER_RADIUS.md,
    backgroundColor: COLORS.cardBg,
  },
  tabItemActive: {
    backgroundColor: COLORS.neonGreen + '18',
    borderWidth: 1,
    borderColor: COLORS.neonGreen + '40',
  },
  tabText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.xs,
    color: COLORS.gray,
  },
  tabTextActive: {
    color: COLORS.neonGreen,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: SPACING.lg,
  },
  // Weekly plan
  weeklyHeaderCard: {
    marginBottom: SPACING.md,
  },
  weeklyHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.md,
  },
  weeklyHeaderTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.lg,
    color: COLORS.white,
  },
  weeklyHeaderSub: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.sm,
    color: COLORS.gray,
    marginTop: 2,
  },
  dayCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderRadius: BORDER_RADIUS.lg,
    padding: SPACING.md,
    marginBottom: SPACING.sm,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  dayCardToday: {
    borderColor: COLORS.neonGreen + '50',
  },
  dayCardLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.md,
    flex: 1,
  },
  dayBadge: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: COLORS.cardBgLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  dayBadgeToday: {
    backgroundColor: COLORS.neonGreen,
  },
  dayBadgeText: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.sm,
    color: COLORS.grayLight,
  },
  dayBadgeTextToday: {
    color: COLORS.black,
  },
  dayInfo: {
    flex: 1,
  },
  dayTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
  },
  dayTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.md,
    color: COLORS.white,
  },
  dayFocus: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.gray,
    marginTop: 2,
  },
  dayMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.md,
    marginTop: SPACING.xs + 2,
  },
  dayMetaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.xs,
  },
  dayMetaText: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.gray,
  },
  // Plan card
  planCard: {
    padding: 0,
    marginBottom: SPACING.md,
    overflow: 'hidden',
  },
  planGradient: {
    padding: SPACING.lg,
    borderRadius: BORDER_RADIUS.lg,
  },
  planTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: SPACING.md,
  },
  planIconBox: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: COLORS.neonGreen + '15',
    alignItems: 'center',
    justifyContent: 'center',
  },
  planMeta: {
    flexDirection: 'row',
    gap: SPACING.xs,
  },
  planName: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.xl,
    color: COLORS.white,
    marginBottom: SPACING.xs,
  },
  planDesc: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.sm,
    color: COLORS.grayLight,
    lineHeight: 20,
    marginBottom: SPACING.md,
  },
  planStatsRow: {
    flexDirection: 'row',
    gap: SPACING.lg,
    marginBottom: SPACING.md,
  },
  planStatItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.xs,
  },
  planStatText: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.gray,
  },
  // Exercise card with image
  exerciseCard: {
    padding: 0,
    marginBottom: SPACING.md,
    overflow: 'hidden',
  },
  exerciseImageContainer: {
    width: '100%',
    height: 180,
    position: 'relative',
  },
  exerciseImage: {
    width: '100%',
    height: '100%',
  },
  exerciseImageOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '60%',
  },
  exerciseImageBadgeRow: {
    position: 'absolute',
    top: SPACING.sm,
    right: SPACING.sm,
  },
  exerciseImageNameOverlay: {
    position: 'absolute',
    bottom: SPACING.sm,
    left: SPACING.md,
    right: SPACING.md,
  },
  exerciseImageName: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.lg,
    color: COLORS.white,
  },
  exerciseImageMeta: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.grayLight,
    marginTop: 2,
    textTransform: 'capitalize',
  },
  exerciseStatsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: SPACING.md,
    gap: SPACING.sm,
  },
  exerciseStat: {
    flex: 1,
    alignItems: 'center',
  },
  exerciseStatLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.gray,
  },
  exerciseStatValue: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.sm,
    color: COLORS.white,
    marginTop: 2,
  },
  exerciseViewBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.xs,
    backgroundColor: COLORS.neonGreen + '15',
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    borderRadius: BORDER_RADIUS.pill,
  },
  exerciseViewText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.xs,
    color: COLORS.neonGreen,
  },
  // Nutrition
  nutritionHeaderCard: {
    alignItems: 'center',
    marginBottom: SPACING.lg,
    paddingVertical: SPACING.xl,
  },
  nutritionHeaderTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.lg,
    color: COLORS.white,
    marginTop: SPACING.sm,
  },
  nutritionHeaderDesc: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.sm,
    color: COLORS.gray,
    marginTop: SPACING.xs,
    textAlign: 'center',
  },
  mealSection: {
    marginBottom: SPACING.lg,
  },
  mealTypeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    marginBottom: SPACING.sm,
  },
  mealTypeTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.lg,
    color: COLORS.white,
  },
  mealCard: {
    marginBottom: SPACING.sm,
  },
  mealName: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.md,
    color: COLORS.white,
    marginBottom: SPACING.xs,
  },
  mealDesc: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.sm,
    color: COLORS.grayLight,
    lineHeight: 20,
    marginBottom: SPACING.md,
  },
  mealStatsRow: {
    flexDirection: 'row',
    gap: SPACING.xs,
    marginBottom: SPACING.md,
  },
  mealStatBox: {
    flex: 1,
    backgroundColor: COLORS.cardBgLight,
    borderRadius: BORDER_RADIUS.sm,
    paddingVertical: SPACING.sm,
    alignItems: 'center',
  },
  mealStatValue: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.md,
    color: COLORS.neonGreen,
  },
  mealStatLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.gray,
    marginTop: 2,
  },
  ingredientsContainer: {
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
    paddingTop: SPACING.md,
  },
  ingredientsTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.sm,
    color: COLORS.white,
    marginBottom: SPACING.xs,
  },
  ingredientItem: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.sm,
    color: COLORS.grayLight,
    marginTop: 2,
  },
  // Modal - shared
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.85)',
    justifyContent: 'flex-end',
  },
  exerciseModalContent: {
    backgroundColor: COLORS.darkGray,
    borderTopLeftRadius: BORDER_RADIUS.xxl,
    borderTopRightRadius: BORDER_RADIUS.xxl,
    maxHeight: '92%',
    paddingBottom: SPACING.lg,
  },
  exerciseModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: SPACING.lg,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  exerciseModalHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.md,
    flex: 1,
  },
  modalIconBox: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: COLORS.neonGreen + '15',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.lg,
    color: COLORS.white,
  },
  modalSubtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.xs,
    color: COLORS.gray,
    marginTop: 2,
    textTransform: 'capitalize',
  },
  closeBtn: {
    padding: SPACING.xs,
  },
  modalScroll: {
    padding: SPACING.lg,
  },
  modalSection: {
    marginBottom: SPACING.lg,
  },
  modalSectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    marginBottom: SPACING.md,
  },
  modalSectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.md,
    color: COLORS.white,
  },
  stepRow: {
    flexDirection: 'row',
    gap: SPACING.md,
    marginBottom: SPACING.md,
  },
  stepNumber: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: COLORS.neonGreen,
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
  stepNumberText: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.xs,
    color: COLORS.black,
  },
  stepText: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.md,
    color: COLORS.offWhite,
    lineHeight: 22,
    flex: 1,
  },
  tipRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: SPACING.md,
    marginBottom: SPACING.sm,
  },
  tipDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: COLORS.neonGreen,
    marginTop: 7,
    flexShrink: 0,
  },
  tipText: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.sm,
    color: COLORS.grayLight,
    lineHeight: 20,
    flex: 1,
  },
  // Exercise detail demonstration
  demonstrationContainer: {
    width: '100%',
    height: 280,
    borderRadius: BORDER_RADIUS.lg,
    overflow: 'hidden',
    marginBottom: SPACING.lg,
    position: 'relative',
  },
  demonstrationImage: {
    width: '100%',
    height: '100%',
  },
  demonstrationOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '60%',
  },
  demonstrationBadge: {
    position: 'absolute',
    top: SPACING.sm,
    left: SPACING.sm,
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.xs,
    backgroundColor: 'rgba(0,0,0,0.7)',
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.xs + 1,
    borderRadius: BORDER_RADIUS.pill,
  },
  demonstrationBadgeText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: FONT_SIZES.xs,
    color: COLORS.neonGreen,
  },
  demonstrationInfoOverlay: {
    position: 'absolute',
    bottom: SPACING.md,
    left: SPACING.md,
    right: SPACING.md,
  },
  demonstrationBadgeRow: {
    flexDirection: 'row',
    gap: SPACING.sm,
    marginBottom: SPACING.sm,
    flexWrap: 'wrap',
  },
  demonstrationFormText: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.sm,
    color: COLORS.offWhite,
    lineHeight: 20,
  },

});

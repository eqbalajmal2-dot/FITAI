import { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, KeyboardAvoidingView, Platform } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { Dumbbell, Mail, Lock, ArrowRight } from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import { Input, NeonButton } from '@/components/ui';
import { COLORS, SPACING, FONT_SIZES, BORDER_RADIUS } from '@/constants/theme';

export default function LoginScreen() {
  const router = useRouter();
  const { signIn } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!email || !password) {
      setError('Please fill in all fields');
      return;
    }
    setError(null);
    setLoading(true);
    const { error } = await signIn(email, password);
    setLoading(false);
    if (error) {
      setError(error);
    }
  };

  return (
    <LinearGradient colors={[COLORS.black, COLORS.darkGray]} style={styles.container}>
      <KeyboardAvoidingView behavior={Platform.OS === 'web' ? undefined : 'padding'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          <View style={styles.header}>
            <LinearGradient
              colors={[COLORS.neonGreen, COLORS.neonGreenDim]}
              style={styles.logoContainer}
            >
              <Dumbbell color={COLORS.black} size={36} strokeWidth={2.5} />
            </LinearGradient>
            <Text style={styles.appName}>FITAI</Text>
            <Text style={styles.tagline}>Your AI Personal Gym Coach</Text>
          </View>

          <View style={styles.formContainer}>
            <Text style={styles.title}>Welcome Back</Text>
            <Text style={styles.subtitle}>Sign in to continue your fitness journey</Text>

            {error && (
              <View style={styles.errorBox}>
                <Text style={styles.errorText}>{error}</Text>
              </View>
            )}

            <View style={styles.inputWrapper}>
              <Mail color={COLORS.gray} size={20} style={styles.inputIcon} />
              <Input
                value={email}
                onChangeText={setEmail}
                placeholder="Email address"
                keyboardType="email-address"
              />
            </View>
            <View style={styles.inputWrapper}>
              <Lock color={COLORS.gray} size={20} style={styles.inputIcon} />
              <Input
                value={password}
                onChangeText={setPassword}
                placeholder="Password"
                secureTextEntry
              />
            </View>

            <NeonButton
              title="Sign In"
              onPress={handleLogin}
              loading={loading}
              icon={<ArrowRight color={COLORS.black} size={18} strokeWidth={2.5} />}
            />

            <View style={styles.footer}>
              <Text style={styles.footerText}>Don't have an account? </Text>
              <TouchableOpacity onPress={() => router.push('/(auth)/signup')}>
                <Text style={styles.footerLink}>Sign Up</Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: SPACING.xl,
  },
  header: {
    alignItems: 'center',
    marginBottom: SPACING.xxl,
  },
  logoContainer: {
    width: 72,
    height: 72,
    borderRadius: BORDER_RADIUS.xl,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: SPACING.md,
  },
  appName: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.xxxl,
    color: COLORS.neonGreen,
    letterSpacing: 3,
  },
  tagline: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.sm,
    color: COLORS.gray,
    marginTop: SPACING.xs,
  },
  formContainer: {
    width: '100%',
    maxWidth: 400,
    alignSelf: 'center',
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: FONT_SIZES.xxl,
    color: COLORS.white,
    marginBottom: SPACING.xs,
  },
  subtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: FONT_SIZES.md,
    color: COLORS.gray,
    marginBottom: SPACING.xl,
  },
  errorBox: {
    backgroundColor: COLORS.errorBg,
    borderRadius: BORDER_RADIUS.md,
    padding: SPACING.md,
    marginBottom: SPACING.md,
    borderWidth: 1,
    borderColor: COLORS.error + '44',
  },
  errorText: {
    color: COLORS.error,
    fontSize: FONT_SIZES.sm,
    fontFamily: 'Inter-Regular',
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 0,
  },
  inputIcon: {
    position: 'absolute',
    left: SPACING.md + 2,
    zIndex: 1,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: SPACING.xl,
  },
  footerText: {
    color: COLORS.gray,
    fontSize: FONT_SIZES.md,
    fontFamily: 'Inter-Regular',
  },
  footerLink: {
    color: COLORS.neonGreen,
    fontSize: FONT_SIZES.md,
    fontFamily: 'Inter-SemiBold',
  },
});

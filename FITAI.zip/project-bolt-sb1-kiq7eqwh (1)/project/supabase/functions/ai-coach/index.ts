import { createClient } from "npm:@supabase/supabase-js@2.58.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const SYSTEM_PROMPT = `You are FITAI, an expert AI personal gym coach and fitness advisor. You provide personalized workout recommendations, exercise form guidance, nutrition advice, and motivation. You are knowledgeable about:
- Strength training, cardio, flexibility, and mobility
- Beginner, intermediate, and advanced workout programming
- Proper exercise form and safety tips
- Nutrition and meal planning for fitness goals
- Recovery and injury prevention
- Progressive overload and periodization

Always be encouraging, specific, and practical. Tailor your advice to the user's stated fitness level and goals. Keep responses concise but thorough. When recommending exercises, mention sets, reps, and rest periods. If asked about something outside fitness, gently steer the conversation back to health and fitness.`;

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Missing authorization header" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const jwt = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabase.auth.getUser(jwt);
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: "Invalid authentication" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const body = await req.json();
    const { messages, profile } = body as {
      messages: ChatMessage[];
      profile?: { fitness_level?: string; fitness_goal?: string; age?: number; weight_kg?: number; height_cm?: number };
    };

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return new Response(
        JSON.stringify({ error: "Messages array is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Build the context with user profile info
    let profileContext = "";
    if (profile) {
      const parts: string[] = [];
      if (profile.fitness_level) parts.push(`Fitness level: ${profile.fitness_level}`);
      if (profile.fitness_goal) parts.push(`Goal: ${profile.fitness_goal}`);
      if (profile.age) parts.push(`Age: ${profile.age}`);
      if (profile.weight_kg) parts.push(`Weight: ${profile.weight_kg}kg`);
      if (profile.height_cm) parts.push(`Height: ${profile.height_cm}cm`);
      if (parts.length > 0) {
        profileContext = `\n\nUser profile: ${parts.join(", ")}. Tailor your advice accordingly.`;
      }
    }

    const openaiKey = Deno.env.get("OPENAI_API_KEY");

    // If no OpenAI key is configured, return a helpful fallback response
    if (!openaiKey) {
      const lastMessage = messages[messages.length - 1]?.content || "";
      const fallbackResponse = generateFallbackResponse(lastMessage, profile);
      // Save the exchange to chat history
      await supabase.from("chat_history").insert([
        { user_id: user.id, role: "user", content: messages[messages.length - 1]?.content || "" },
        { user_id: user.id, role: "assistant", content: fallbackResponse },
      ]);
      return new Response(
        JSON.stringify({ reply: fallbackResponse, fallback: true }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Build conversation for OpenAI
    const conversationMessages = [
      { role: "system", content: SYSTEM_PROMPT + profileContext },
      ...messages.slice(-10).map((m) => ({ role: m.role, content: m.content })),
    ];

    const openaiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${openaiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: conversationMessages,
        max_tokens: 800,
        temperature: 0.7,
      }),
    });

    if (!openaiResponse.ok) {
      const errText = await openaiResponse.text();
      console.error("OpenAI API error:", errText);
      const fallbackResponse = generateFallbackResponse(messages[messages.length - 1]?.content || "", profile);
      await supabase.from("chat_history").insert([
        { user_id: user.id, role: "user", content: messages[messages.length - 1]?.content || "" },
        { user_id: user.id, role: "assistant", content: fallbackResponse },
      ]);
      return new Response(
        JSON.stringify({ reply: fallbackResponse, fallback: true }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const openaiData = await openaiResponse.json();
    const reply = openaiData.choices?.[0]?.message?.content || "I'm here to help with your fitness journey!";

    // Save the exchange to chat history
    await supabase.from("chat_history").insert([
      { user_id: user.id, role: "user", content: messages[messages.length - 1]?.content || "" },
      { user_id: user.id, role: "assistant", content: reply },
    ]);

    return new Response(
      JSON.stringify({ reply }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("Edge function error:", err);
    return new Response(
      JSON.stringify({ error: "An unexpected error occurred. Please try again." }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

function generateFallbackResponse(userMessage: string, profile?: { fitness_level?: string }): string {
  const level = profile?.fitness_level || "beginner";
  const msg = userMessage.toLowerCase();

  if (msg.includes("workout") || msg.includes("exercise") || msg.includes("routine")) {
    return `Here's a great ${level} workout you can try:\n\n1. Push-Ups - 3 sets x 12 reps (45s rest)\n2. Bodyweight Squats - 3 sets x 15 reps (45s rest)\n3. Plank - 3 sets x 30 seconds (45s rest)\n4. Lunges - 3 sets x 10 per leg (45s rest)\n5. Mountain Climbers - 3 sets x 30 seconds (30s rest)\n\nThis full-body routine targets all major muscle groups. Rest 60-90 seconds between exercises. Remember to warm up for 5 minutes before starting and stretch afterward.\n\nFor a personalized plan, check out the Workouts tab where you'll find tailored plans for your fitness level!`;
  }

  if (msg.includes("diet") || msg.includes("nutrition") || msg.includes("eat") || msg.includes("meal") || msg.includes("food")) {
    return `Here are some general nutrition tips for your fitness journey:\n\n- Eat protein with every meal (lean meats, eggs, fish, beans)\n- Include complex carbs (oats, brown rice, sweet potatoes)\n- Don't skip healthy fats (avocado, nuts, olive oil)\n- Stay hydrated - aim for 8 glasses of water daily\n- Time your meals: eat 1-2 hours before workouts\n\nSample meal plan:\nBreakfast: Oatmeal with berries and nuts\nLunch: Grilled chicken with quinoa and vegetables\nDinner: Salmon with sweet potato and greens\nSnacks: Greek yogurt, fruit, or protein shake\n\nCheck the Diet & Nutrition section in the Workouts tab for more personalized suggestions!`;
  }

  if (msg.includes("weight") || msg.includes("lose") || msg.includes("fat")) {
    return `To lose weight effectively:\n\n1. Create a moderate calorie deficit (300-500 calories below maintenance)\n2. Prioritize protein to preserve muscle mass\n3. Combine strength training with cardio (3-4x per week)\n4. Stay consistent - sustainable changes beat crash diets\n5. Track your progress using the Progress tab\n\nStart with the HIIT Cardio Burn or Full Body Beginner workout plan. Aim for 3-4 workouts per week and gradually increase intensity as you get stronger.`;
  }

  if (msg.includes("muscle") || msg.includes("gain") || msg.includes("build") || msg.includes("bulk")) {
    return `To build muscle effectively:\n\n1. Eat in a slight calorie surplus (200-300 above maintenance)\n2. Consume 1.6-2.2g of protein per kg of bodyweight\n3. Focus on progressive overload - gradually increase weight or reps\n4. Prioritize compound exercises (squats, deadlifts, bench press, rows)\n5. Get 7-9 hours of sleep for recovery\n\nCheck out the Upper Body Blast or Advanced Strength workout plans in the Workouts tab!`;
  }

  if (msg.includes("beginner") || msg.includes("start") || msg.includes("new")) {
    return `Welcome to your fitness journey! Here's how to get started as a ${level}:\n\n1. Start with 3 workouts per week, resting between sessions\n2. Focus on proper form before adding weight\n3. Try the "Full Body Beginner" workout plan in the Workouts tab\n4. Track your water intake in the Progress tab\n5. Be patient - consistency is more important than intensity\n\nYou're already taking the first step by being here. Every rep counts!`;
  }

  return `I'm your FITAI coach, ready to help with workouts, nutrition, form guidance, and motivation! Try asking me about:\n\n- Workout routines for your level\n- Nutrition and meal plans\n- How to lose weight or build muscle\n- Exercise form and safety tips\n- Getting started as a beginner\n\nYou can also explore the Workouts tab for pre-built plans and the Progress tab to track your journey!`;
}

/*
# FITAI - Complete Database Schema

## Overview
Creates the full database schema for the FITAI AI Gym Coach application, including user profiles,
workout history, water intake tracking, chat history with the AI coach, and workout plans.
Also seeds the database with sample exercise library and workout plan data.

## New Tables
1. `profiles` - Extended user profile data (name, age, weight, height, fitness level, goals)
2. `workout_history` - Records of completed workouts (exercises, duration, calories, date)
3. `water_intake` - Daily water consumption tracking (glasses, date)
4. `chat_history` - AI coach conversation history (role, content, timestamp)
5. `exercises` - Exercise library with instructions, safety tips, muscle groups, difficulty
6. `workout_plans` - Pre-built workout plans (name, difficulty, exercises, duration)

## Security
- All user-specific tables (profiles, workout_history, water_intake, chat_history) have RLS enabled
  with owner-scoped policies (auth.uid() = user_id) and DEFAULT auth.uid() on user_id columns
- Public tables (exercises, workout_plans) are readable by anon + authenticated
- Grants are explicit per role and verb
- service_role granted on user tables for potential edge function use

## Important Notes
- user_id columns default to auth.uid() so inserts from the client work without passing user_id
- All policies use auth.uid() (never current_user)
- 4 separate policies per table (SELECT/INSERT/UPDATE/DELETE), no FOR ALL
*/

-- ============================================================================
-- PROFILES TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  age integer,
  weight_kg numeric,
  height_cm numeric,
  fitness_level text NOT NULL DEFAULT 'beginner' CHECK (fitness_level IN ('beginner', 'intermediate', 'advanced')),
  fitness_goal text NOT NULL DEFAULT 'general fitness',
  avatar_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON profiles TO authenticated;
GRANT SELECT, UPDATE ON profiles TO service_role;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "delete_own_profile" ON profiles;
CREATE POLICY "delete_own_profile" ON profiles FOR DELETE
  TO authenticated USING (auth.uid() = id);

-- ============================================================================
-- WORKOUT HISTORY TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS workout_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  workout_name text NOT NULL,
  exercises jsonb NOT NULL DEFAULT '[]'::jsonb,
  duration_minutes integer NOT NULL DEFAULT 0,
  calories_burned integer NOT NULL DEFAULT 0,
  difficulty text NOT NULL DEFAULT 'beginner',
  completed_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE workout_history ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON workout_history TO authenticated;
GRANT SELECT ON workout_history TO service_role;

CREATE INDEX IF NOT EXISTS idx_workout_history_user_id ON workout_history(user_id);
CREATE INDEX IF NOT EXISTS idx_workout_history_completed_at ON workout_history(completed_at DESC);

DROP POLICY IF EXISTS "select_own_workouts" ON workout_history;
CREATE POLICY "select_own_workouts" ON workout_history FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_workouts" ON workout_history;
CREATE POLICY "insert_own_workouts" ON workout_history FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_workouts" ON workout_history;
CREATE POLICY "update_own_workouts" ON workout_history FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_workouts" ON workout_history;
CREATE POLICY "delete_own_workouts" ON workout_history FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============================================================================
-- WATER INTAKE TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS water_intake (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  glasses integer NOT NULL DEFAULT 0,
  intake_date date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, intake_date)
);

ALTER TABLE water_intake ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON water_intake TO authenticated;
GRANT SELECT ON water_intake TO service_role;

CREATE INDEX IF NOT EXISTS idx_water_intake_user_date ON water_intake(user_id, intake_date);

DROP POLICY IF EXISTS "select_own_water" ON water_intake;
CREATE POLICY "select_own_water" ON water_intake FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_water" ON water_intake;
CREATE POLICY "insert_own_water" ON water_intake FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_water" ON water_intake;
CREATE POLICY "update_own_water" ON water_intake FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_water" ON water_intake;
CREATE POLICY "delete_own_water" ON water_intake FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============================================================================
-- CHAT HISTORY TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS chat_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user', 'assistant')),
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE chat_history ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, DELETE ON chat_history TO authenticated;
GRANT SELECT ON chat_history TO service_role;

CREATE INDEX IF NOT EXISTS idx_chat_history_user_id ON chat_history(user_id);
CREATE INDEX IF NOT EXISTS idx_chat_history_created_at ON chat_history(created_at);

DROP POLICY IF EXISTS "select_own_chat" ON chat_history;
CREATE POLICY "select_own_chat" ON chat_history FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_chat" ON chat_history;
CREATE POLICY "insert_own_chat" ON chat_history FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_chat" ON chat_history;
CREATE POLICY "delete_own_chat" ON chat_history FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ============================================================================
-- EXERCISES TABLE (public library)
-- ============================================================================
CREATE TABLE IF NOT EXISTS exercises (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  muscle_group text NOT NULL,
  difficulty text NOT NULL CHECK (difficulty IN ('beginner', 'intermediate', 'advanced')),
  equipment text NOT NULL DEFAULT 'bodyweight',
  instructions text[] NOT NULL DEFAULT '{}',
  safety_tips text[] NOT NULL DEFAULT '{}',
  sets_reps text NOT NULL DEFAULT '3 x 12',
  rest_seconds integer NOT NULL DEFAULT 60,
  calories_per_set integer NOT NULL DEFAULT 8,
  icon_name text NOT NULL DEFAULT 'Dumbbell',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE exercises ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON exercises TO anon, authenticated;

DROP POLICY IF EXISTS "read_exercises" ON exercises;
CREATE POLICY "read_exercises" ON exercises FOR SELECT
  TO anon, authenticated USING (true);

-- ============================================================================
-- WORKOUT PLANS TABLE (public library)
-- ============================================================================
CREATE TABLE IF NOT EXISTS workout_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL DEFAULT '',
  difficulty text NOT NULL CHECK (difficulty IN ('beginner', 'intermediate', 'advanced')),
  category text NOT NULL DEFAULT 'strength',
  duration_minutes integer NOT NULL DEFAULT 30,
  calories_estimate integer NOT NULL DEFAULT 200,
  exercise_ids jsonb NOT NULL DEFAULT '[]'::jsonb,
  icon_name text NOT NULL DEFAULT 'Dumbbell',
  color text NOT NULL DEFAULT '#00FF87',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE workout_plans ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON workout_plans TO anon, authenticated;

DROP POLICY IF EXISTS "read_workout_plans" ON workout_plans;
CREATE POLICY "read_workout_plans" ON workout_plans FOR SELECT
  TO anon, authenticated USING (true);

-- ============================================================================
-- UPDATED_AT TRIGGER FOR PROFILES
-- ============================================================================
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS profiles_updated_at ON profiles;
CREATE TRIGGER profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============================================================================
-- SEED DATA: EXERCISES
-- ============================================================================
INSERT INTO exercises (name, muscle_group, difficulty, equipment, instructions, safety_tips, sets_reps, rest_seconds, calories_per_set, icon_name) VALUES
('Push-Ups', 'Chest', 'beginner', 'bodyweight',
  ARRAY['Start in a plank position with hands shoulder-width apart', 'Lower your body until your chest nearly touches the floor', 'Keep your core tight and elbows at 45 degrees', 'Push back up to the starting position'],
  ARRAY['Keep your body in a straight line', 'Do not let your hips sag', 'Breathe out as you push up'],
  '3 x 12', 45, 8, 'Dumbbell'),
('Bodyweight Squats', 'Legs', 'beginner', 'bodyweight',
  ARRAY['Stand with feet shoulder-width apart', 'Lower your hips as if sitting in a chair', 'Keep your knees behind your toes', 'Return to standing position'],
  ARRAY['Keep your chest up', 'Do not let knees cave inward', 'Go as low as your mobility allows'],
  '3 x 15', 45, 10, 'Dumbbell'),
('Dumbbell Bicep Curls', 'Arms', 'beginner', 'dumbbells',
  ARRAY['Stand with a dumbbell in each hand, palms forward', 'Curl the weights toward your shoulders', 'Squeeze your biceps at the top', 'Slowly lower back down'],
  ARRAY['Keep your elbows close to your body', 'Do not swing your back', 'Control the descent'],
  '3 x 12', 60, 7, 'Dumbbell'),
('Plank', 'Core', 'beginner', 'bodyweight',
  ARRAY['Get into a forearm plank position', 'Keep your body straight from head to heels', 'Hold the position while breathing steadily'],
  ARRAY['Do not let your hips drop', 'Engage your core and glutes', 'Keep your neck neutral'],
  '3 x 30 seconds', 45, 5, 'Dumbbell'),
('Lunges', 'Legs', 'beginner', 'bodyweight',
  ARRAY['Step forward with one leg', 'Lower your back knee toward the floor', 'Push back to the starting position', 'Alternate legs'],
  ARRAY['Keep your torso upright', 'Do not let your front knee go past your toes', 'Maintain balance'],
  '3 x 10 each leg', 45, 9, 'Dumbbell'),
('Mountain Climbers', 'Core', 'beginner', 'bodyweight',
  ARRAY['Start in a plank position', 'Drive one knee toward your chest', 'Switch legs rapidly', 'Keep your core engaged'],
  ARRAY['Keep your hips low', 'Maintain a steady rhythm', 'Breathe steadily'],
  '3 x 30 seconds', 30, 10, 'Dumbbell'),
('Dumbbell Shoulder Press', 'Shoulders', 'beginner', 'dumbbells',
  ARRAY['Sit or stand with dumbbells at shoulder height', 'Press the dumbbells overhead', 'Lower them back to your shoulders'],
  ARRAY['Keep your core tight', 'Do not lock your elbows', 'Avoid arching your back'],
  '3 x 10', 60, 8, 'Dumbbell'),
('Bench Press', 'Chest', 'intermediate', 'barbell',
  ARRAY['Lie on a flat bench with feet on the floor', 'Grip the barbell slightly wider than shoulder-width', 'Lower the bar to your chest', 'Press the bar back up'],
  ARRAY['Use a spotter for heavy lifts', 'Keep your shoulder blades retracted', 'Do not bounce the bar off your chest'],
  '4 x 10', 90, 12, 'Dumbbell'),
('Deadlift', 'Back', 'intermediate', 'barbell',
  ARRAY['Stand with feet hip-width apart, bar over mid-foot', 'Bend at hips and knees to grip the bar', 'Keep your back flat and chest up', 'Drive through your heels and stand up tall'],
  ARRAY['Keep your spine neutral', 'Do not round your back', 'Engage your lats before lifting'],
  '4 x 8', 120, 15, 'Dumbbell'),
('Pull-Ups', 'Back', 'intermediate', 'pull-up bar',
  ARRAY['Grab the bar with an overhand grip', 'Hang with arms fully extended', 'Pull your chin above the bar', 'Lower yourself with control'],
  ARRAY['Engage your core to prevent swinging', 'Do not kip or use momentum', 'Lower fully between reps'],
  '3 x 8', 90, 11, 'Dumbbell'),
('Overhead Press', 'Shoulders', 'intermediate', 'barbell',
  ARRAY['Start with the barbell at shoulder height', 'Press the bar overhead until arms are extended', 'Lower the bar back to your shoulders'],
  ARRAY['Brace your core', 'Do not arch your back excessively', 'Keep the bar path vertical'],
  '4 x 8', 90, 10, 'Dumbbell'),
('Romanian Deadlift', 'Legs', 'intermediate', 'dumbbells',
  ARRAY['Hold dumbbells in front of your thighs', 'Hinge at the hips, pushing glutes back', 'Lower the weights along your legs', 'Drive hips forward to return'],
  ARRAY['Keep a slight bend in your knees', 'Maintain a flat back', 'Feel the stretch in your hamstrings'],
  '3 x 12', 75, 12, 'Dumbbell'),
('Bent-Over Rows', 'Back', 'intermediate', 'dumbbells',
  ARRAY['Hinge forward at the hips with a flat back', 'Hold dumbbells with arms extended', 'Pull the weights to your ribcage', 'Lower with control'],
  ARRAY['Keep your back flat', 'Squeeze your shoulder blades', 'Do not twist your torso'],
  '4 x 10', 75, 11, 'Dumbbell'),
('Barbell Back Squat', 'Legs', 'advanced', 'barbell',
  ARRAY['Set the bar on your upper traps', 'Unrack and stand with feet shoulder-width apart', 'Descend until thighs are parallel', 'Drive up through your heels'],
  ARRAY['Use safety bars in the rack', 'Keep your knees tracking over your toes', 'Maintain a tight core throughout'],
  '5 x 5', 180, 18, 'Dumbbell'),
('Weighted Dips', 'Arms', 'advanced', 'dip station',
  ARRAY['Support yourself on parallel bars', 'Lower your body until shoulders are below elbows', 'Push back up to full extension'],
  ARRAY['Do not shrug your shoulders', 'Lean forward to target chest', 'Stop if you feel shoulder pain'],
  '4 x 8', 90, 14, 'Dumbbell'),
('Muscle-Ups', 'Back', 'advanced', 'pull-up bar',
  ARRAY['Start with a false grip on the bar', 'Pull up explosively', 'Transition to a dip position', 'Press up and over the bar'],
  ARRAY['Master pull-ups and dips first', 'Use a kipping motion if needed', 'Practice the transition slowly'],
  '3 x 5', 120, 16, 'Dumbbell'),
('Pistol Squats', 'Legs', 'advanced', 'bodyweight',
  ARRAY['Stand on one leg with the other extended forward', 'Lower into a full squat on one leg', 'Keep your arms forward for balance', 'Drive back up to standing'],
  ARRAY['Build single-leg strength first', 'Use a support if needed', 'Keep your knee aligned'],
  '3 x 6 each leg', 90, 15, 'Dumbbell'),
('Hanging Leg Raises', 'Core', 'advanced', 'pull-up bar',
  ARRAY['Hang from a bar with arms extended', 'Raise your legs to hip height or higher', 'Lower your legs with control'],
  ARRAY['Avoid swinging', 'Keep your legs straight', 'Engage your lower abs'],
  '3 x 12', 60, 12, 'Dumbbell')
ON CONFLICT DO NOTHING;

-- ============================================================================
-- SEED DATA: WORKOUT PLANS
-- ============================================================================
INSERT INTO workout_plans (name, description, difficulty, category, duration_minutes, calories_estimate, exercise_ids, icon_name, color) VALUES
('Full Body Beginner', 'A complete full-body workout for those starting their fitness journey. Targets all major muscle groups with foundational exercises.',
  'beginner', 'strength', 30, 180,
  '["Push-Ups","Bodyweight Squats","Plank","Lunges","Mountain Climbers"]',
  'Dumbbell', '#00FF87'),
('Upper Body Blast', 'Focus on building strength in your chest, back, shoulders, and arms with this intermediate upper body session.',
  'intermediate', 'strength', 45, 320,
  '["Bench Press","Pull-Ups","Overhead Press","Dumbbell Bicep Curls","Bent-Over Rows"]',
  'Dumbbell', '#00FF87'),
('Leg Day Power', 'Build powerful legs with this comprehensive lower body workout targeting quads, hamstrings, and glutes.',
  'intermediate', 'strength', 40, 300,
  '["Deadlift","Romanian Deadlift","Bodyweight Squats","Lunges"]',
  'Dumbbell', '#00FF87'),
('Core Crusher', 'An intense core-focused session to build a strong, defined midsection from planks to hanging leg raises.',
  'beginner', 'core', 25, 150,
  '["Plank","Mountain Climbers","Hanging Leg Raises"]',
  'Dumbbell', '#00FF87'),
('Advanced Strength', 'A high-intensity full body workout for experienced lifters. Features compound movements and advanced techniques.',
  'advanced', 'strength', 60, 450,
  '["Barbell Back Squat","Deadlift","Weighted Dips","Muscle-Ups","Pistol Squats"]',
  'Dumbbell', '#00FF87'),
('Arm Builder', 'Isolate and grow your arms with targeted bicep and tricep exercises for maximum definition.',
  'beginner', 'strength', 20, 130,
  '["Dumbbell Bicep Curls","Push-Ups","Dumbbell Shoulder Press"]',
  'Dumbbell', '#00FF87'),
('HIIT Cardio Burn', 'High-intensity interval training to maximize calorie burn and boost cardiovascular endurance.',
  'beginner', 'cardio', 25, 250,
  '["Mountain Climbers","Bodyweight Squats","Lunges","Plank"]',
  'Dumbbell', '#00FF87')
ON CONFLICT DO NOTHING;
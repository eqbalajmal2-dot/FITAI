export const EXERCISE_IMAGES: Record<string, string> = {
  'Push-Ups': 'https://images.pexels.com/photos/4920478/pexels-photo-4920478.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
  'Bodyweight Squats': 'https://images.pexels.com/photos/4720555/pexels-photo-4720555.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
  'Dumbbell Bicep Curls': 'https://images.pexels.com/photos/12314077/pexels-photo-12314077.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
  'Plank': 'https://images.pexels.com/photos/8173429/pexels-photo-8173429.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
  'Lunges': 'https://images.pexels.com/photos/4720840/pexels-photo-4720840.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
  'Mountain Climbers': 'https://images.pexels.com/photos/2294361/pexels-photo-2294361.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
  'Dumbbell Shoulder Press': 'https://images.pexels.com/photos/7289370/pexels-photo-7289370.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
  'Bench Press': 'https://images.pexels.com/photos/3916762/pexels-photo-3916762.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
  'Deadlift': 'https://images.pexels.com/photos/4853280/pexels-photo-4853280.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
  'Pull-Ups': 'https://images.pexels.com/photos/9644816/pexels-photo-9644816.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
  'Overhead Press': 'https://images.pexels.com/photos/4164841/pexels-photo-4164841.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
  'Romanian Deadlift': 'https://images.pexels.com/photos/1552103/pexels-photo-1552103.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
  'Bent-Over Rows': 'https://images.pexels.com/photos/13018368/pexels-photo-13018368.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
  'Barbell Back Squat': 'https://images.pexels.com/photos/2261477/pexels-photo-2261477.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
  'Weighted Dips': 'https://images.pexels.com/photos/4803702/pexels-photo-4803702.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
  'Muscle-Ups': 'https://images.pexels.com/photos/4090063/pexels-photo-4090063.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
  'Pistol Squats': 'https://images.pexels.com/photos/6799554/pexels-photo-6799554.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
  'Hanging Leg Raises': 'https://images.pexels.com/photos/4803714/pexels-photo-4803714.jpeg?auto=compress&cs=tinysrgb&h=400&w=600',
};

export function getExerciseImage(name: string): string {
  return EXERCISE_IMAGES[name] || 'https://images.pexels.com/photos/3888350/pexels-photo-3888350.jpeg?auto=compress&cs=tinysrgb&h=400&w=600';
}

export interface WeeklyDay {
  day: string;
  shortDay: string;
  title: string;
  focus: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  icon: string;
  exercises: string[];
}

export const WEEKLY_PLAN: WeeklyDay[] = [
  {
    day: 'Monday',
    shortDay: 'Mon',
    title: 'Chest & Triceps',
    focus: 'Push Day',
    difficulty: 'intermediate',
    icon: 'Dumbbell',
    exercises: ['Push-Ups', 'Bench Press', 'Dumbbell Shoulder Press', 'Weighted Dips'],
  },
  {
    day: 'Tuesday',
    shortDay: 'Tue',
    title: 'Back & Biceps',
    focus: 'Pull Day',
    difficulty: 'intermediate',
    icon: 'Dumbbell',
    exercises: ['Pull-Ups', 'Bent-Over Rows', 'Dumbbell Bicep Curls', 'Deadlift'],
  },
  {
    day: 'Wednesday',
    shortDay: 'Wed',
    title: 'Legs & Glutes',
    focus: 'Lower Body',
    difficulty: 'intermediate',
    icon: 'Dumbbell',
    exercises: ['Bodyweight Squats', 'Barbell Back Squat', 'Romanian Deadlift', 'Lunges'],
  },
  {
    day: 'Thursday',
    shortDay: 'Thu',
    title: 'Active Recovery',
    focus: 'Core & Mobility',
    difficulty: 'beginner',
    icon: 'Dumbbell',
    exercises: ['Plank', 'Mountain Climbers', 'Hanging Leg Raises'],
  },
  {
    day: 'Friday',
    shortDay: 'Fri',
    title: 'Full Body Power',
    focus: 'Compound Movements',
    difficulty: 'advanced',
    icon: 'Dumbbell',
    exercises: ['Deadlift', 'Bench Press', 'Barbell Back Squat', 'Pull-Ups'],
  },
  {
    day: 'Saturday',
    shortDay: 'Sat',
    title: 'Calisthenics & Core',
    focus: 'Bodyweight Strength',
    difficulty: 'advanced',
    icon: 'Dumbbell',
    exercises: ['Muscle-Ups', 'Pistol Squats', 'Push-Ups', 'Hanging Leg Raises'],
  },
  {
    day: 'Sunday',
    shortDay: 'Sun',
    title: 'Rest & Recovery',
    focus: 'Light Stretching',
    difficulty: 'beginner',
    icon: 'Dumbbell',
    exercises: [],
  },
];

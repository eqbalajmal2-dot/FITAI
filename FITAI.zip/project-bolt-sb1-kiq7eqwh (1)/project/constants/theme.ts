export const COLORS = {
  black: '#0A0A0A',
  darkGray: '#141414',
  cardBg: '#1A1A1A',
  cardBgLight: '#222222',
  border: '#2A2A2A',
  neonGreen: '#00FF87',
  neonGreenDim: '#00CC6A',
  neonGreenDark: '#008844',
  white: '#FFFFFF',
  offWhite: '#F5F5F5',
  gray: '#888888',
  grayLight: '#AAAAAA',
  grayDark: '#333333',
  error: '#FF4444',
  errorBg: '#2A1414',
  warning: '#FFAA00',
  success: '#00FF87',
  successBg: '#0A2218',
  accent: '#00FF87',
  accentBlue: '#00BFFF',
  danger: '#FF3B30',
};

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const FONT_SIZES = {
  xs: 11,
  sm: 13,
  md: 15,
  lg: 18,
  xl: 22,
  xxl: 28,
  xxxl: 36,
};

export const BORDER_RADIUS = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 28,
  pill: 999,
};

export const SHADOWS = {
  neon: {
    shadowColor: '#00FF87',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 5,
  },
  card: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 8,
    elevation: 4,
  },
};
